-- phpMyAdmin SQL Dump
-- version 3.4.3.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 08, 2012 at 08:29 PM
-- Server version: 5.0.67
-- PHP Version: 5.4.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES latin1 */;

--
-- Database: `store_en`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_best_visitors`
--

CREATE TABLE IF NOT EXISTS `info_best_visitors` (
  `time` text NOT NULL,
  `v_count` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info_best_visitors`
--

INSERT INTO `info_best_visitors` (`time`, `v_count`) VALUES
('07-Oct-2009 Hour : 13:33', 1);

-- --------------------------------------------------------

--
-- Table structure for table `info_browser`
--

CREATE TABLE IF NOT EXISTS `info_browser` (
  `name` text NOT NULL,
  `count` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info_browser`
--

INSERT INTO `info_browser` (`name`, `count`) VALUES
('Netscape', 146),
('MSIE', 6710),
('Lynx', 0),
('Opera', 0),
('WebTV', 0),
('Konqueror', 0),
('Bot', 0),
('Other', 0);

-- --------------------------------------------------------

--
-- Table structure for table `info_hits`
--

CREATE TABLE IF NOT EXISTS `info_hits` (
  `date` text NOT NULL,
  `hits` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `info_online`
--

CREATE TABLE IF NOT EXISTS `info_online` (
  `time` int(15) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  PRIMARY KEY  (`time`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info_online`
--

INSERT INTO `info_online` (`time`, `ip`) VALUES
(1265729405, '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `info_os`
--

CREATE TABLE IF NOT EXISTS `info_os` (
  `name` text NOT NULL,
  `count` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info_os`
--

INSERT INTO `info_os` (`name`, `count`) VALUES
('Windows', 6856),
('Mac', 0),
('Linux', 0),
('FreeBSD', 0),
('SunOS', 0),
('IRIX', 0),
('BeOS', 0),
('OS/2', 0),
('AIX', 0),
('Other', 0);

-- --------------------------------------------------------

--
-- Table structure for table `store_access_log`
--

CREATE TABLE IF NOT EXISTS `store_access_log` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_banners`
--

CREATE TABLE IF NOT EXISTS `store_banners` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `ord` int(11) NOT NULL default '0',
  `type` varchar(255) NOT NULL default '',
  `views` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `menu_id` int(11) NOT NULL default '0',
  `menu_pos` text NOT NULL,
  `pages` text NOT NULL,
  `content` text NOT NULL,
  `c_type` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`),
  KEY `ord` (`ord`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `store_banners`
--

INSERT INTO `store_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`, `active`) VALUES
(1, 'Allomani Programming Services', 'http://allomani.com', 'http://allomani.com/allomani_banner.gif', '2006-06-10 01:00:00', 1, 'footer', 41603, 33, 0, 'l', 'main,browse,product_details,news,pages,search,votes,statics,contactus,', '', 'img', 0),
(2, 'Allomani Programming Services', 'http://allomani.com', 'http://allomani.com/allomani_banner.gif', '0000-00-00 00:00:00', 1, 'header', 70535, 23, 0, 'r', 'main,news,pages,search,votes,statics,contactus,', '', 'img', 1),
(17, 'Playstatus 3 Slim', 'details_2.html', 'data/banners/offer_3.gif', '2009-07-26 05:41:18', 1, 'offer', 861, 5, 0, 'r', 'main,news,pages,search,votes,statics,contactus,', 'Ps3 Slim Available Now', 'img', 1),
(16, 'Buy One and get Another for Free', 'details_3.html', 'data/banners/offer_1.gif', '2009-07-26 05:38:14', 0, 'offer', 861, 5, 0, 'r', 'main,news,pages,search,votes,statics,contactus,', 'Now , buy 1 iphone and get the another for free', 'img', 1),
(14, 'Disabled Banner', 'http://', '', '2008-12-06 21:07:45', 0, 'menu', 11, 0, 1, 'c', 'main,news,pages,search,votes,statics,contactus,', '', 'img', 0),
(19, 'Dell Inspiron 11z', 'details_5.html', 'data/banners/offer_2.gif', '2009-07-26 06:44:58', 0, 'offer', 852, 10, 0, 'r', 'main,news,pages,search,votes,statics,contactus,', 'Available Now', 'img', 1);

-- --------------------------------------------------------

--
-- Table structure for table `store_blocks`
--

CREATE TABLE IF NOT EXISTS `store_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `pos` varchar(20) NOT NULL default '',
  `file` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `template` text NOT NULL,
  `pages` text NOT NULL,
  `hide_title` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`),
  KEY `pos` (`pos`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `store_blocks`
--

INSERT INTO `store_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`, `hide_title`, `cat`) VALUES
(10, 'Search', 'l', '<form method="postt" action="index.php">\r\n<input type=hidden name="action" value="search">\r\n\r\n<input type=text name="keyword" size="12" tabindex="1">\r\n<br>\r\n<select name=op>\r\n<option value=''''>Products</option>\r\n<option value=''news''>News</option>\r\n</select>\r\n\r\n<input type=submit value="Search" tabindex="1">\r\n</form>', 5, 1, '0', 'main,browse,product_details,news,pages,search,votes,statics,contactus,', 0, 0),
(8, 'Main Menu', 'l', '<?\r\nglobal $style;\r\n\r\nprint "\r\n<img src=''$style[images]/home.gif''>&nbsp;<a href=''index.php''>Home Page</a><br>\r\n<img src=''$style[images]/products.gif''>&nbsp;<a href=''browse.html''>Products</a><br>\r\n<img src=''$style[images]/news.gif''>&nbsp;<a href=''index.php?action=news''>News</a><br>\r\n<img src=''$style[images]/statics.gif''>&nbsp;<a href=''index.php?action=statics''>Statics</a><br>\r\n<img src=''$style[images]/contactus.gif''>&nbsp;<a href=''index.php?action=contactus''>Contact us</a><br>";\r\n?>', 0, 1, '0', 'main,browse,product_details,news,pages,search,votes,statics,contactus,', 0, 0),
(11, 'Votes', 'r', '<?\r\n$qr_title = db_query("select * from store_votes_cats  where active=1");\r\nif(db_num($qr_title)){\r\n\r\n$data_title = db_fetch($qr_title);\r\nprint "<center>$data_title[title]</center>";\r\n$qr = mysql_query("select * from store_votes where cat=$data_title[id]");\r\nprint "<form action=\\"index.php\\" method=\\"post\\">\r\n<input type=''hidden'' name=''action'' value=''vote_add''>\r\n";\r\n\r\n while ($data = mysql_fetch_array($qr)){\r\n\r\n        print "<input type=''radio'' value=''$data[id]'' name=''vote_id''>$data[title]<br>";\r\n\r\n\r\n\r\n }\r\nprint "<center><br><input type=''submit'' value=''Vote''> <br><br><a href=''index.php?action=votes''>Results </a></center></form>";\r\n}else{\r\nprint "<center> No Active Votes </center>";\r\n}\r\n?>', 2, 1, '0', 'main,product_details,news,pages,search,votes,statics,contactus,', 0, 0),
(4, 'Now Online', 'l', '<?\r\nglobal $counter ;\r\n\r\nprint "<p align=center>  There are $counter[online_users] visitor browsing now</p>";\r\n\r\nprint "<p dir=rtl align=center>Best visitors count in $counter[best_visit] at : <br> $counter[best_visit_time] <br></p>";\r\n\r\n', 4, 1, '0', 'main,browse,product_details,news,pages,search,votes,statics,contactus,', 0, 0),
(18, 'Last News', 'c', '<?\r\nglobal $data,$phrases;\r\n$qr = db_query("select * from store_news order by id DESC limit 4");\r\n\r\nif(db_num($qr)){\r\nprint "<center>\r\n<hr width=90% class=separate_line size=\\"1\\">\r\n<table width=100%><tr>" ;\r\n\r\nwhile($data = db_fetch($qr)){\r\n\r\n\r\nprint "<tr><td>";\r\ncompile_template(get_template(''browse_news''));  \r\nprint "<hr width=90% class=separate_line size=\\"1\\"></td></tr>";\r\n\r\n        }\r\nprint "</tr></table>";\r\n}else{\r\nprint "<center> $phrases[no_news]</center>";\r\n}\r\n       ?>', 5, 1, '0', 'main,', 0, 0),
(37, 'Shopping Cart', 'r', '<?\r\nglobal $phrases,$style;\r\n\r\nprint "<div id=\\"cart_loading_div\\" style=\\"display:none;\\"><img src=''$style[images]/ajax_loading.gif''></div>\r\n<div id=\\"cart_div\\"></div>\r\n\r\n<br><br>\r\n<a href=''javascript:;'' onClick=\\"get_cart_items();\\"><img src=''$style[images]/cart_refresh.gif'' border=0>&nbsp;$phrases[cart_update]</a>\r\n<br>\r\n<a href=''javascript:cart_clear();'' onClick=\\"return confirm(''$phrases[are_you_sure]'');\\"><img src=''$style[images]/cart_clear.gif'' border=0>&nbsp;$phrases[cart_clear]</a>\r\n<br><br>\r\n\r\n<script>\r\nget_cart_items();\r\n</script>";\r\n?>', 0, 1, '0', 'main,browse,product_details,news,pages,search,votes,statics,contactus,', 0, 0),
(38, 'Features', 'l', '<?\r\nglobal $phrases;\r\n\r\ninclude "products_fields.php";\r\n?>', 1, 1, '0', 'browse,product_details,', 0, 0),
(20, 'Last Items', 'c', '<?\r\nglobal $settings,$data,$phrases,$data_cat,$data_cat_cache;\r\n\r\n$qr=db_query("select * from store_products_data where active=1 order by id DESC limit 4") ;\r\nif(db_num($qr)){\r\n\r\n compile_template(get_template(''browse_products_header'')); \r\n\r\n$c=0 ;\r\n\r\n\r\n\r\nwhile ($data = db_fetch($qr)){\r\n\r\n if(isset($data_cat_cache[$data[''cat'']])){\r\n $data_cat = $data_cat_cache[$data[''cat'']] ;\r\n}else{ \r\n $data_cat = db_qr_fetch("select id,name from store_products_cats where id=''$data[cat]''");\r\n$data_cat_cache[$data[''cat'']]  = $data_cat ;\r\n} \r\n\r\n\r\nif ($c==$settings[''img_cells'']) {\r\ncompile_template(get_template(''browse_products_spect''));  \r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n compile_template(get_template(''browse_products''));   \r\n\r\n              }\r\n compile_template(get_template(''browse_products_footer''));  \r\n\r\n}else{\r\nprint "<center> $phrases[no_products]</center>";\r\n}\r\n?>', 4, 1, '0', 'main,', 0, 42),
(21, 'Main Categories', 'l', '<?\r\nglobal $style,$links;\r\n$cats_qr=db_query("select * from store_products_cats where active=1 and cat=0 order by ord asc");\r\nwhile($data = db_fetch($cats_qr)){\r\n       print "<img src=''$style[images]/cat.gif''>&nbsp;<a href=''".str_replace(''{id}'',$data[''id''],$links[''links_browse_products''])."''>$data[name]</a><br>";\r\n\r\n\r\n        }', 3, 1, '0', 'main,browse,product_details,news,pages,search,votes,statics,contactus,', 0, 0),
(23, 'Statics', 'r', '<?\r\nglobal $phrases,$style;\r\n\r\n\r\n   $data5 = db_qr_fetch("select count(id) as count from store_products_data");\r\n  $count_cats = db_qr_fetch("select count(id) as count from store_products_cats");\r\n\r\n\r\nprint "\r\n\r\n<img src=\\"$style[images]/products.gif\\">&nbsp;<b> $phrases[products_count] : </b> $data5[count] <br>\r\n<img src=\\"$style[images]/cat.gif\\">&nbsp;<b>  Categories Count : </b> $count_cats[count] ";\r\n?>', 3, 1, '0', 'main,product_details,news,pages,search,votes,statics,contactus,', 0, 0),
(31, 'Clients', 'l', '<?\r\nglobal $member_data,$phrases,$style ;\r\n\r\nif(check_member_login()){\r\n\r\n\r\nprint "<center>  Welcome $member_data[username] <br> <br>" ;\r\n$nw_msgs = db_qr_fetch("select count(id) as count from store_clients_msgs where user = $member_data[id] and opened=0");\r\n\r\nif($nw_msgs[''count''] >0){\r\nprint "<font color=red> You Have $nw_msgs[count] New Messages</font><br><br>";\r\n}\r\n\r\nprint "\r\n</center>\r\n<img src=''$style[images]/my_orders.gif''>&nbsp;<a href=''index.php?action=my_orders''>My Orders</a> <br> \r\n<img src=''$style[images]/my_addresses.gif''>&nbsp;<a href=''index.php?action=addresses''>My Addresses</a> <br>    \r\n<img src=''$style[images]/favorite_small.gif''>&nbsp;<a href=''index.php?action=favorites''>$phrases[the_favorite]</a> <br>\r\n<img src=''$style[images]/msgs.gif''>&nbsp;<a href=''index.php?action=msgs''>$phrases[the_messages]</a><br>\r\n<img src=''$style[images]/profile.gif''>&nbsp;<a href=''index.php?action=profile''>$phrases[the_profile]</a><br>\r\n<img src=''$style[images]/logout.gif''>&nbsp;<a href=''login.php?action=logout''>$phrases[logout]</a><br>\r\n</center><br>";\r\n}else{\r\nprint "<script type=\\"text/javascript\\" src=\\"js/md5.js\\"></script>\r\n\r\n<form method=\\"POST\\" action=\\"login.php\\" onsubmit=\\"md5hash(password, md5pwd, md5pwd_utf, 1)\\">\r\n\r\n<input type=hidden name=''md5pwd'' value=''''>\r\n<input type=hidden name=''md5pwd_utf'' value=''''>\r\n\r\n\r\n<input type=hidden name=action value=login>\r\n<input type=hidden name=re_link value=\\"$_SERVER[REQUEST_URI]\\">\r\n<table border=\\"0\\" width=\\"100%\\">\r\n    <tr>\r\n        <td height=\\"15\\">$phrases[username] :</span></td></tr><tr>\r\n        <td height=\\"15\\"><input type=\\"text\\" name=\\"username\\" size=\\"10\\"></td>\r\n    </tr>\r\n    <tr>\r\n        <td height=\\"12\\">$phrases[password] :</span></td></tr><tr>\r\n        <td height=\\"12\\" ><input type=\\"password\\" name=\\"password\\" size=\\"10\\"></td>\r\n    </tr>\r\n    <tr>\r\n        <td height=\\"23\\">\r\n        <p align=\\"center\\">\r\n<br><input type=\\"submit\\" value=\\"$phrases[login_do]\\"></td>\r\n    </tr>\r\n    <tr>\r\n        <td height=\\"38\\">\r\n<br>\r\n    <img src=''$style[images]/new_client.gif''>&nbsp;<a href=\\"index.php?action=register\\">$phrases[newuser]</a><br>\r\n    <img src=''$style[images]/forgot_pass.gif''>&nbsp;<a href=\\"index.php?action=forget_pass\\">$phrases[forgot_pass]</a></td>\r\n    </tr>\r\n</table>\r\n</form>";\r\n\r\n}\r\n?>', 2, 1, '0', 'main,browse,product_details,news,pages,search,votes,statics,contactus,', 0, 0),
(35, 'RSS & Sitemap', 'r', '<?\r\n$qr=db_query("select * from store_products_cats where cat=''0''");\r\nprint "\r\n<center>\r\n<img src=''images/rss_feed.gif'' title=''RSS''><br><br>\r\n<form action=rss.php method=get>\r\n<select name=cat>\r\n<option value=''0''>All</option>";\r\nwhile($data = db_fetch($qr)){\r\nprint "<option value=''$data[id]''>$data[name]</option>";\r\n}\r\nprint "</select><br><br><input type=submit value='' View ''>\r\n</form>\r\n<hr class=separate_line size=1>\r\n<br>\r\n<a href=''sitemap.xml''><img src=''images/sitemap.gif'' title=''Sitemap'' border=0><br>Sitemap</a>\r\n</center>";\r\n', 4, 1, '0', 'main,browse,product_details,news,pages,search,votes,statics,contactus,', 1, 0),
(39, 'Random Items', 'c', '<?\r\nglobal $settings,$data,$phrases,$data_cat,$data_cat_cache ;\r\n\r\n$qr=db_query("select * from store_products_data where active=1 order by rand() limit 4") ;\r\nif(db_num($qr)){\r\n\r\n compile_template(get_template(''browse_products_header'')); \r\n\r\n$c=0 ;\r\n\r\nwhile ($data = db_fetch($qr)){\r\n\r\n   \r\n if(isset($data_cat_cache[$data[''cat'']])){\r\n $data_cat = $data_cat_cache[$data[''cat'']] ;\r\n}else{ \r\n $data_cat = db_qr_fetch("select id,name from store_products_cats where id=''$data[cat]''");\r\n$data_cat_cache[$data[''cat'']]  = $data_cat ;\r\n}  \r\n\r\n\r\nif ($c==$settings[''img_cells'']) {\r\ncompile_template(get_template(''browse_products_spect''));  \r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n compile_template(get_template(''browse_products''));   \r\n\r\n              }\r\n compile_template(get_template(''browse_products_footer''));  \r\n\r\n}else{\r\nprint "<center> $phrases[no_products]</center>";\r\n}\r\n?>', 3, 1, '0', 'main,', 0, 42),
(41, 'Offers', 'c', '<?\r\n\r\n$qr=db_query("select * from store_banners where `type` like ''offer'' and active=1 order by ord");\r\nif(db_num($qr)){\r\n\r\ninclude_once("includes/class_slider.php");\r\n\r\nopen_table();\r\n$slider = new slider("slider");      \r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n$ids[] = $data[''id''];\r\n\r\n$slider->start($data[''id'']);\r\nprint "<center>".iif($data[''url''],"<a href=\\"banner.php?id=$data[id]\\" target=_blank>").iif($data[''img''],"<img border=0 src=\\"$data[img]\\" alt=\\"$data[title]\\"><br><br>").$data[''content''].iif($data[''url''],"</a>")."</center>";\r\n\r\n$slider->end();  \r\n}\r\n\r\n\r\n$slider->run();\r\ndb_query("update store_banners set views=views+1 where id IN (".implode(",",$ids).")");\r\nclose_table();\r\n}\r\n?>\r\n', 1, 1, 'no_title_no_border', 'main,', 1, 0),
(42, 'Hot Items', 'c', '<?\r\nglobal $settings,$data,$phrases,$data_cat,$data_cat_cache ;\r\n\r\n$qr=db_query("select store_hot_items.product_id,store_products_data.*  from store_hot_items,store_products_data where store_products_data.id=store_hot_items.product_id and store_products_data.active=1 order by store_hot_items.ord asc");\r\n\r\nif(db_num($qr)){\r\n\r\n compile_template(get_template(''browse_products_header'')); \r\n\r\n$c=0 ;\r\n\r\nwhile ($data = db_fetch($qr)){\r\n\r\n   \r\n if(isset($data_cat_cache[$data[''cat'']])){\r\n $data_cat = $data_cat_cache[$data[''cat'']] ;\r\n}else{ \r\n $data_cat = db_qr_fetch("select id,name from store_products_cats where id=''$data[cat]''");\r\n$data_cat_cache[$data[''cat'']]  = $data_cat ;\r\n} \r\n\r\n\r\n\r\nif ($c==$settings[''img_cells'']) {\r\ncompile_template(get_template(''browse_products_spect''));  \r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n compile_template(get_template(''browse_products''));   \r\n\r\n              }\r\n compile_template(get_template(''browse_products_footer''));  \r\n\r\n}else{\r\nprint "<center> $phrases[no_products]</center>";\r\n}\r\n?>', 2, 1, '0', 'main,', 0, 0),
(44, 'Related Items', 'r', '<?\r\nglobal $id,$action,$links,$phrases;\r\n\r\nif($action=="product_details"){\r\n$product = db_qr_fetch("select name from store_products_data where id=''$id''");\r\n\r\n$qr = db_query("select *,match(name) against(''".db_escape($product[''name''])."'') as score from store_products_data where id !=''$id'' and match(name) against(''".db_escape($product[''name''])."'') order by score");   \r\n\r\nif(db_num($qr)){\r\n                                                                              \r\n \r\nopen_block("$phrases[related_products]");\r\nprint "<table width=100%>";\r\nwhile($data=db_fetch($qr)){\r\nprint "<tr><td><img src=\\"".get_image($data[''thumb''])."\\" width=40 height=40></td><td><a href=''".str_replace(''{id}'',$data[''id''],$links[''links_product_details''])."''>$data[name]</a></td></tr><tr><td colspan=2><hr class=separate_line size=1></td></tr>";\r\n}\r\nprint "</table>";\r\nclose_block();\r\n}\r\n\r\n}', 1, 1, 'no_title_no_border', 'product_details,', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `store_clients`
--

CREATE TABLE IF NOT EXISTS `store_clients` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `active_code` text NOT NULL,
  `sex` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  `usr_group` int(11) NOT NULL default '0',
  `birth` date NOT NULL default '0000-00-00',
  `country` text NOT NULL,
  `mobile` text NOT NULL,
  `members_list` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_clients_addresses`
--

CREATE TABLE IF NOT EXISTS `store_clients_addresses` (
  `id` int(11) NOT NULL auto_increment,
  `client_id` int(11) NOT NULL default '0',
  `address_title` text NOT NULL,
  `name` text NOT NULL,
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `tel` text NOT NULL,
  `country` text NOT NULL,
  `city` text NOT NULL,
  `default_billing` int(11) NOT NULL default '0',
  `default_shipping` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `client_id` (`client_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_clients_favorites`
--

CREATE TABLE IF NOT EXISTS `store_clients_favorites` (
  `id` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `product_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_clients_fields`
--

CREATE TABLE IF NOT EXISTS `store_clients_fields` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `member` int(11) NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_clients_msgs`
--

CREATE TABLE IF NOT EXISTS `store_clients_msgs` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `user` int(11) NOT NULL default '0',
  `sender` text NOT NULL,
  `opened` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_clients_sets`
--

CREATE TABLE IF NOT EXISTS `store_clients_sets` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `details` text NOT NULL,
  `type` text NOT NULL,
  `value` text NOT NULL,
  `style` text NOT NULL,
  `required` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `store_clients_sets`
--

INSERT INTO `store_clients_sets` (`id`, `name`, `details`, `type`, `value`, `style`, `required`, `ord`) VALUES
(5, 'Sex', '', 'select', 'Male\r\nFemale', '', 0, 0),
(6, 'Contact #', 'Tel. or Mobile #', 'text', '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `store_confirmations`
--

CREATE TABLE IF NOT EXISTS `store_confirmations` (
  `id` int(11) NOT NULL auto_increment,
  `type` text NOT NULL,
  `old_value` text NOT NULL,
  `new_value` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `code` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_countries`
--

CREATE TABLE IF NOT EXISTS `store_countries` (
  `name` varchar(80) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_countries`
--

INSERT INTO `store_countries` (`name`) VALUES
('Afghanistan'),
('Albania'),
('Algeria'),
('American Samoa'),
('Andorra'),
('Angola'),
('Anguilla'),
('Antarctica'),
('Antigua and Barbuda'),
('Argentina'),
('Armenia'),
('Aruba'),
('Australia'),
('Austria'),
('Azerbaijan'),
('Bahamas'),
('Bahrain'),
('Bangladesh'),
('Barbados'),
('Belarus'),
('Belgium'),
('Belize'),
('Benin'),
('Bermuda'),
('Bhutan'),
('Bolivia'),
('Bosnia and Herzegovina'),
('Botswana'),
('Bouvet Island'),
('Brazil'),
('British Indian Ocean Territory'),
('Brunei Darussalam'),
('Bulgaria'),
('Burkina Faso'),
('Burundi'),
('Cambodia'),
('Cameroon'),
('Canada'),
('Cape Verde'),
('Cayman Islands'),
('Central African Republic'),
('Chad'),
('Chile'),
('China'),
('Christmas Island'),
('Cocos (Keeling) Islands'),
('Colombia'),
('Comoros'),
('Congo'),
('Cook Islands'),
('Costa Rica'),
('Cote D''Ivoire'),
('Croatia'),
('Cuba'),
('Cyprus'),
('Czech Republic'),
('Denmark'),
('Djibouti'),
('Dominica'),
('Dominican Republic'),
('Ecuador'),
('Egypt'),
('El Salvador'),
('Equatorial Guinea'),
('Eritrea'),
('Estonia'),
('Ethiopia'),
('Faroe Islands'),
('Fiji'),
('Finland'),
('France'),
('Gabon'),
('Gambia'),
('Georgia'),
('Germany'),
('Ghana'),
('Gibraltar'),
('Greece'),
('Greenland'),
('Grenada'),
('Guadeloupe'),
('Guam'),
('Guatemala'),
('Guinea'),
('Guinea-Bissau'),
('Guyana'),
('Haiti'),
('Honduras'),
('Hong Kong'),
('Hungary'),
('Iceland'),
('India'),
('Indonesia'),
('Iraq'),
('Ireland'),
('Israel'),
('Italy'),
('Jamaica'),
('Japan'),
('Jordan'),
('Kazakhstan'),
('Kenya'),
('Kiribati'),
('Korea, Republic of'),
('Kuwait'),
('Kyrgyzstan'),
('Latvia'),
('Lebanon'),
('Lesotho'),
('Liberia'),
('Libyan Arab Jamahiriya'),
('Liechtenstein'),
('Lithuania'),
('Luxembourg'),
('Macao'),
('Madagascar'),
('Malawi'),
('Malaysia'),
('Maldives'),
('Mali'),
('Malta'),
('Marshall Islands'),
('Martinique'),
('Mauritania'),
('Mauritius'),
('Mayotte'),
('Mexico'),
('Monaco'),
('Mongolia'),
('Montserrat'),
('Morocco'),
('Mozambique'),
('Myanmar'),
('Namibia'),
('Nauru'),
('Nepal'),
('Netherlands'),
('Netherlands Antilles'),
('New Caledonia'),
('New Zealand'),
('Nicaragua'),
('Niger'),
('Nigeria'),
('Niue'),
('Norfolk Island'),
('Norway'),
('Oman'),
('Pakistan'),
('Palau'),
('Panama'),
('Papua New Guinea'),
('Paraguay'),
('Peru'),
('Philippines'),
('Pitcairn'),
('Poland'),
('Portugal'),
('Puerto Rico'),
('Qatar'),
('Reunion'),
('Romania'),
('Russian Federation'),
('Rwanda'),
('Saint Helena'),
('Saint Kitts and Nevis'),
('Saint Lucia'),
('Saint Pierre and Miquelon'),
('Samoa'),
('San Marino'),
('Sao Tome and Principe'),
('Saudi Arabia'),
('Senegal'),
('Serbia and Montenegro'),
('Seychelles'),
('Sierra Leone'),
('Singapore'),
('Slovakia'),
('Slovenia'),
('Solomon Islands'),
('Somalia'),
('South Africa'),
('Spain'),
('Sri Lanka'),
('Sudan'),
('Suriname'),
('Svalbard and Jan Mayen'),
('Swaziland'),
('Sweden'),
('Switzerland'),
('Syrian Arab Republic'),
('Taiwan, Province of China'),
('Tajikistan'),
('Thailand'),
('Timor-Leste'),
('Togo'),
('Tokelau'),
('Tonga'),
('Trinidad and Tobago'),
('Tunisia'),
('Turkey'),
('Turkmenistan'),
('Turks and Caicos Islands'),
('Tuvalu'),
('Uganda'),
('Ukraine'),
('United Arab Emirates'),
('United Kingdom'),
('United States'),
('Uruguay'),
('Uzbekistan'),
('Vanuatu'),
('Venezuela'),
('Viet Nam'),
('Virgin Islands, British'),
('Virgin Islands, U.s.'),
('Wallis and Futuna'),
('Western Sahara'),
('Yemen'),
('Zambia'),
('Zimbabwe'),
('Palestine');

-- --------------------------------------------------------

--
-- Table structure for table `store_fields_data`
--

CREATE TABLE IF NOT EXISTS `store_fields_data` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `product_id` int(11) NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_fields_options`
--

CREATE TABLE IF NOT EXISTS `store_fields_options` (
  `id` int(11) NOT NULL auto_increment,
  `value` text NOT NULL,
  `img` text NOT NULL,
  `field_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `field_id` (`field_id`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `store_fields_options`
--

INSERT INTO `store_fields_options` (`id`, `value`, `img`, `field_id`, `ord`) VALUES
(1, '1100cc to 1600cc', '', 1, 0),
(2, '2000cc', '', 1, 0),
(3, '1.6 Ghz to 2.0 Ghz', '', 2, 1),
(4, 'Intel Core2Due', '', 3, 0),
(5, 'AMD Turion X2', '', 3, 4),
(6, 'DELL', '', 4, 1),
(7, 'HP', '', 4, 2),
(8, 'Toshiba', '', 4, 3),
(9, 'Acer', '', 4, 0),
(10, '2.4 Ghz  to 2.6 Ghz', '', 2, 2),
(11, 'New', '', 5, 0),
(12, 'Used', '', 5, 0),
(13, 'Wi-Fi', 'data/fields/wifi.gif', 7, 1),
(14, 'Bluetooth', 'data/fields/bluetooth.gif', 7, 2),
(15, 'LightScribe', '', 7, 5),
(16, 'HDMI', 'data/fields/hdmi.gif', 7, 3),
(17, 'Intel Celeron', '', 3, 3),
(18, 'Intel DualCore', '', 3, 1),
(19, 'Intel Pentium 4', '', 3, 2),
(20, 'Apple', '', 9, 0),
(21, 'Nokia', '', 9, 0),
(22, 'Sony Ericsson', '', 9, 0),
(23, 'Samsung', '', 9, 0),
(24, 'BlackBerry', '', 9, 0),
(25, '2.0 Ghz', '', 10, 4),
(26, '2.5 Ghz', '', 10, 1),
(27, '2.4 Ghz', '', 10, 2),
(28, '2.6 Ghz', '', 10, 0),
(29, '1.7 Ghz', '', 10, 5),
(30, 'S-Video', '', 7, 4),
(31, 'Webcam', 'data/fields/cam.gif', 7, 0),
(32, '1.0 Ghz  to 1.5 Ghz', '', 2, 0),
(33, '1.3 Ghz', '', 10, 6),
(34, 'BMW', '', 11, 0),
(35, 'Audi', '', 11, 0),
(36, 'Toyota', '', 11, 0),
(37, 'CD player', '', 12, 0),
(38, 'Driver airbag', '', 12, 0),
(39, 'Passenger airbag', '', 12, 0),
(40, 'Side airbags', '', 12, 0),
(41, 'Anti-lock brakes', '', 12, 0),
(42, 'GPS', '', 12, 0),
(43, 'Power windows', '', 12, 0),
(44, 'Power locks', '', 12, 0),
(45, 'Air conditioning', '', 12, 0),
(46, 'Power seats', '', 12, 0),
(47, 'New', '', 15, 0),
(48, 'Used', '', 15, 0),
(49, '15.6 Inch', '', 16, 0),
(50, '13.3 Inch', '', 16, 0),
(51, '2.3 Ghz', '', 10, 3),
(52, 'Cars', '', 19, 0),
(53, 'Action', '', 19, 1),
(54, 'Adventure', '', 19, 2),
(55, 'Action', '', 20, 0),
(56, 'Comedy', '', 20, 1),
(57, 'DVD', '', 21, 0),
(58, 'Blueray', '', 21, 1),
(59, 'VCD', '', 21, 2),
(60, '2009', '', 22, 0),
(61, '2008', '', 22, 1),
(62, '2007', '', 22, 2),
(63, 'Animation', '', 20, 2);

-- --------------------------------------------------------

--
-- Table structure for table `store_fields_sets`
--

CREATE TABLE IF NOT EXISTS `store_fields_sets` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `title` text NOT NULL,
  `type` text NOT NULL,
  `value` text NOT NULL,
  `style` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `cats` text NOT NULL,
  `in_search` int(11) NOT NULL default '0',
  `in_details` int(11) NOT NULL default '0',
  `in_short_details` int(11) NOT NULL default '0',
  `img` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `ord` (`ord`),
  KEY `active` (`active`),
  KEY `in_search` (`in_search`),
  KEY `in_details` (`in_details`),
  KEY `in_short_details` (`in_short_details`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `store_fields_sets`
--

INSERT INTO `store_fields_sets` (`id`, `name`, `title`, `type`, `value`, `style`, `ord`, `active`, `cats`, `in_search`, `in_details`, `in_short_details`, `img`) VALUES
(1, 'Cars - Motor CC', 'Motor CC', 'select', '', '', 14, 1, '', 1, 1, 0, ''),
(2, 'Laptops - CPU Speed (Search)', 'CPU Speed', 'select', '', '', 1, 1, '', 1, 0, 0, ''),
(3, 'Laptops - CPU Type', 'CPU Type', 'select', '', '', 3, 1, '', 1, 1, 0, ''),
(4, 'Laptops - Company', 'Company', 'select', '', '', 0, 1, '', 1, 1, 0, ''),
(5, 'Product Condition', 'Condition', 'select', '', '', 6, 1, '', 1, 1, 0, ''),
(6, 'Product Number', 'Product #', 'text', 'Not Available', '', 4, 1, '', 1, 1, 0, ''),
(7, 'Laptops - Features', 'Features', 'checkbox', '', '', 7, 1, '', 1, 1, 0, ''),
(8, 'Cars - Mileage', 'Mileage', 'text', '', '', 13, 1, '', 1, 1, 0, ''),
(11, 'Cars - Company', 'Company', 'select', '', '', 9, 1, '', 1, 1, 0, ''),
(9, 'Mobiles - Company', 'Company', 'select', '', '', 8, 1, '', 1, 1, 0, ''),
(10, 'Laptops - CPU Speed (Details)', 'CPU Speed', 'select', '', '', 2, 1, '', 0, 1, 0, ''),
(12, 'Cars - Features', 'Features', 'checkbox', '', '', 15, 1, '', 1, 1, 0, ''),
(13, 'Cars - Color', 'Color', 'text', '', '', 10, 1, '', 1, 1, 0, ''),
(14, 'Cars - Seates Color', 'Seates Color', 'text', '', '', 11, 1, '', 1, 1, 0, ''),
(15, 'Cars - Condition', 'Condition', 'select', '', '', 12, 1, '', 1, 1, 0, ''),
(16, 'Laptops - Screen', 'Screen', 'select', '', '', 5, 1, '', 1, 1, 0, ''),
(19, 'Games - Type', 'Game Type', 'select', '', '', 16, 1, '', 1, 1, 0, ''),
(20, 'Films - Type', 'Film Type', 'select', '', '', 17, 1, '', 1, 1, 0, ''),
(21, 'Films - Disk Format', 'Disk Format', 'select', '', '', 18, 1, '', 1, 1, 0, ''),
(22, 'Films - Year', 'Year', 'select', '', '', 19, 1, '', 1, 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `store_hooks`
--

CREATE TABLE IF NOT EXISTS `store_hooks` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `hookid` text NOT NULL,
  `code` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_hot_items`
--

CREATE TABLE IF NOT EXISTS `store_hot_items` (
  `id` int(11) NOT NULL auto_increment,
  `product_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `store_hot_items`
--

INSERT INTO `store_hot_items` (`id`, `product_id`, `ord`) VALUES
(38, 3, 1),
(37, 5, 0),
(39, 2, 2),
(40, 7, 3);

-- --------------------------------------------------------

--
-- Table structure for table `store_news`
--

CREATE TABLE IF NOT EXISTS `store_news` (
  `id` int(11) NOT NULL auto_increment,
  `writer` text NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `details` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `img` text NOT NULL,
  `timeout` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `search` (`title`,`content`,`details`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_orders`
--

CREATE TABLE IF NOT EXISTS `store_orders` (
  `id` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` int(11) NOT NULL default '0',
  `status_text` text NOT NULL,
  `paid` int(11) NOT NULL default '0',
  `billing_name` text NOT NULL,
  `billing_country` text NOT NULL,
  `billing_city` text NOT NULL,
  `billing_address1` text NOT NULL,
  `billing_address2` text NOT NULL,
  `billing_telephone` text NOT NULL,
  `shipping_name` text NOT NULL,
  `shipping_country` text NOT NULL,
  `shipping_city` text NOT NULL,
  `shipping_address1` text NOT NULL,
  `shipping_address2` text NOT NULL,
  `shipping_telephone` text NOT NULL,
  `payment_method_name` text NOT NULL,
  `payment_method_id` int(11) NOT NULL default '0',
  `shipping_method_id` int(11) NOT NULL default '0',
  `shipping_method_name` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_orders_comments`
--

CREATE TABLE IF NOT EXISTS `store_orders_comments` (
  `id` int(11) NOT NULL default '0',
  `order_id` int(11) NOT NULL default '0',
  `name` text NOT NULL,
  `content` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `store_orders_items`
--

CREATE TABLE IF NOT EXISTS `store_orders_items` (
  `id` int(11) NOT NULL auto_increment,
  `order_id` int(11) NOT NULL default '0',
  `name` text NOT NULL,
  `price` double NOT NULL default '0',
  `qty` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_orders_status`
--

CREATE TABLE IF NOT EXISTS `store_orders_status` (
  `id` int(11) NOT NULL auto_increment,
  `active` int(11) NOT NULL default '0',
  `name` text NOT NULL,
  `text_color` text NOT NULL,
  `default` int(11) NOT NULL default '0',
  `default_if_shipping` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `details` text NOT NULL,
  `show_payment` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `store_orders_status`
--

INSERT INTO `store_orders_status` (`id`, `active`, `name`, `text_color`, `default`, `default_if_shipping`, `ord`, `details`, `show_payment`) VALUES
(1, 1, 'Waiting Payment', '#B3B300', 1, 0, 0, 'waiting for payment', 1),
(2, 1, 'Pending', '#000000', 0, 1, 1, 'Pending sales review', 0),
(3, 1, 'Refused', 'red', 0, 0, 2, '', 0),
(4, 1, 'in Shipping Process', '', 0, 0, 3, '', 0),
(5, 1, 'Done', 'green', 0, 0, 4, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `store_pages`
--

CREATE TABLE IF NOT EXISTS `store_pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_payment_gateways`
--

CREATE TABLE IF NOT EXISTS `store_payment_gateways` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `title` text NOT NULL,
  `code` text NOT NULL,
  `img` text NOT NULL,
  `details` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `store_payment_gateways`
--

INSERT INTO `store_payment_gateways` (`id`, `name`, `title`, `code`, `img`, `details`, `ord`, `active`) VALUES
(1, 'PayPal', 'PayPal', '<?\r\nglobal $data_order,$phrases;\r\n//print_r($data_order);\r\n\r\nprint "<center><br><form name=\\"payment\\" action=\\"https://www.paypal.com/cgibin/webscr\\" method=\\"post\\">\r\n<input type=\\"hidden\\" name=\\"cmd\\" value=\\"_xclick\\"> \r\n<input type=\\"hidden\\" name=\\"upload\\" value=\\"1\\"> \r\n<input type=\\"hidden\\" name=\\"currency_code\\" value=\\"USD\\"> \r\n<input type=\\"hidden\\" name=\\"business\\" value=\\"sales@allomani.com\\"> \r\n<input type=\\"hidden\\" name=\\"notify_url\\" value=\\"http://notify.php\\"> \r\n<input type=\\"hidden\\" name=\\"item_name\\" value=\\"Invoice #".$data_order[''id'']."\\"> \r\n<input type=\\"hidden\\" name=\\"return\\" value=\\"http://return_url.php\\"> \r\n<input type=\\"hidden\\" name=\\"cancel_return\\" value=\\"http://cancel_return.php\\"> \r\n<input type=\\"hidden\\" name=\\"invoice\\" value=\\"$data_order[id]\\"> \r\n<input type=\\"hidden\\" name=\\"firstname\\" value=\\"\\"> \r\n<input type=\\"hidden\\" name=\\"lastname\\" value=\\"\\"> \r\n<input type=\\"hidden\\" name=\\"address1\\" value=\\"\\"> \r\n<input type=\\"hidden\\" name=\\"address2\\" value=\\"\\"> \r\n<input type=\\"hidden\\" name=\\"city\\" value=\\"$data_order[city]\\"> \r\n<input type=\\"hidden\\" name=\\"state\\" value=\\"\\"> \r\n<input type=\\"hidden\\" name=\\"zip\\" value=\\"\\"> \r\n<input type=\\"hidden\\" name=\\"rm\\" value=\\"2\\"> \r\n<input type=\\"hidden\\" name=\\"amount\\" value=\\"".number_format($data_order[price],2,".","")."\\">";\r\n\r\nprint "<input type=\\"submit\\" value=\\"$phrases[pay_now]\\">\r\n</form></center>";\r\n?>', 'data/payment/paypal.png', '', 1, 1),
(2, 'moneybookers', 'MoneyBookers', '<?\r\nglobal $data_order,$phrases ;\r\n\r\n$mb_email  = "info@allomani.com";\r\n\r\nprint "<center><br>\r\n<form method=post action=\\"https://www.moneybookers.com/app/payment.pl\\" target=\\"_blank\\">\r\n<input type=\\"hidden\\" name=\\"pay_to_email\\" value=\\"$mb_email\\">\r\n<input type=\\"hidden\\" name=\\"return_url\\" value=\\"http://$domain_name\\">\r\n<input type=\\"hidden\\" name=\\"language\\" value=\\"EN\\">\r\n<input type=\\"hidden\\" name=\\"amount\\" value=\\"".$data_order[''price'']."\\">\r\n<input type=\\"hidden\\" name=\\"currency\\" value=\\"USD\\">\r\n<input type=\\"hidden\\" name=\\"detail1_description\\" value=\\"Invoice # : \\">\r\n<input type=\\"hidden\\" name=\\"detail1_text\\" value=\\"$data_order[id]\\">\r\n\r\n <input type=submit value=\\"$phrases[pay_now]\\">\r\n               </form></center> ";', 'data/payment/moneybookers.png', '', 0, 1),
(3, 'plimus', 'Plimus', '<?\r\n\r\nglobal $data_order,$phrases;\r\n\r\n$plimus_userid = 1759666;\r\n\r\nprint "<center><br>\r\n<form action=\\"https://www.plimus.com/jsp/buynow.jsp\\" method=\\"post\\">  \\n";\r\nprint "\\n";\r\nprint "\\n";\r\nprint "<input type=hidden name=contractId value=$plimus_userid> \\n";\r\nprint "\\n";\r\nprint "<input type=hidden name=overridePrice value=$data_order[price]>\\n";\r\nprint "<input type=hidden name=paymentWire value=N>\\n";\r\nprint "<input type=hidden name=paymentPhone value=N>\\n";\r\nprint "<input type=hidden name=paymentFax value=N>\\n";\r\nprint "<input type=hidden name=paymentMail value=N>\\n";\r\nprint "<input type=hidden name=paymentPO value=N>\\n";\r\nprint "<input type=hidden name=\\"order details\\" value=\\"Invoice #".$data_order[''id'']."\\">\\n";\r\nprint "<input type=hidden name=\\"custom1\\" value=\\"Invoice #".$data_order[''id'']."\\">\\n";\r\nprint "<input type=hidden name=\\"custom2\\" value=\\"\\">\\n";\r\nprint "\\n";\r\nprint "<input type=submit value=\\"$phrases[pay_now]\\">\\n";\r\nprint "</form></center>\\n";', 'data/payment/plimus.png', '', 2, 1),
(4, 'CashU', 'CashU', '<?\r\nglobal $data_order,$phrases;\r\n\r\n$merchant_id = "allomani";\r\n$SecretWord  = "XXX";\r\n\r\n\r\n$token = md5("$merchant_id:$data_order[price]:usd:$SecretWord");\r\n\r\nprint "<center><form action=\\"https://www.cashu.com/cgi-bin/pcashu.cgi\\" method=\\"post\\" >\r\n\r\n<input type=\\"hidden\\" name=\\"merchant_id\\" value=\\"$merchant_id\\">\r\n\r\n<input type=\\"hidden\\" name=\\"token\\" value=\\"$token\\">\r\n\r\n<input type=\\"hidden\\" name=\\"display_text\\" value=\\"Invoice Number : $data_order[id]\\">\r\n<input type=\\"hidden\\" name=\\"txt1\\" value=\\"Invoice Number : $data_order[id]\\">  \r\n\r\n\r\n<input type=\\"hidden\\" name=\\"currency\\" value=\\"USD\\">\r\n\r\n<input type=\\"hidden\\" name=\\"amount\\" value=\\"$data_order[price]\\">\r\n\r\n<input type=\\"hidden\\" name=\\"language\\" value=\\"ar\\">\r\n\r\n\r\n<input type=\\"hidden\\" name=\\"session_id\\" value=\\"\\">\r\n<br>\r\n<input type=submit value=''$phrases[pay_now]''>\r\n</form></center>";\r\n?>', 'data/payment/cashu.png', '', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `store_payment_methods`
--

CREATE TABLE IF NOT EXISTS `store_payment_methods` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `img` text NOT NULL,
  `details` text NOT NULL,
  `is_gateway` int(11) NOT NULL default '0',
  `gateways` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `store_payment_methods`
--

INSERT INTO `store_payment_methods` (`id`, `name`, `img`, `details`, `is_gateway`, `gateways`, `ord`, `active`) VALUES
(1, 'Cash on Receive', 'data/payment/cash.png', 'collect payment by shipping person', 0, '', 0, 1),
(5, 'CashU', 'data/payment/cashu.png', '', 1, '4', 3, 1),
(2, 'Bank Transfer', 'data/payment/bank_wire.png', 'you can edit this text from payment methods to add bank account details or custom page url', 0, '', 1, 1),
(3, 'Credit Card', 'data/payment/cc.png', '', 1, '2,1,3', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `store_phrases`
--

CREATE TABLE IF NOT EXISTS `store_phrases` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `value` text NOT NULL,
  `cat` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=702 ;

--
-- Dumping data for table `store_phrases`
--

INSERT INTO `store_phrases` (`id`, `name`, `value`, `cat`) VALUES
(560, 'click_and_drag_to_change_order', 'Click and Drag to Change Order', 'cp'),
(559, 'access_log', 'Access Log', 'cp'),
(624, 'add_to_cart', 'Add to Cart', 'main'),
(6, 'contact_us', 'Contact us', 'main'),
(7, 'no_results', 'No Results', 'main'),
(8, 'search_results', 'Search Results', 'main'),
(558, 'currency_mark', 'Currency Mark', 'cp'),
(557, 'products_perpage', 'Products Perpage', 'cp'),
(556, 'admin_email', 'Admin Email', 'cp'),
(555, 'page_description', 'Page Description', 'cp'),
(554, 'hide_title', 'Hide Title', 'cp'),
(16, 'err_no_page', 'Sorry , This page is not exists', 'main'),
(17, 'type_search_keyword', 'Please type search keyword , Minimum {letters} Letters', 'main'),
(18, 'the_name', 'Name', 'main'),
(19, 'add_date', 'Add Date', 'main'),
(21, 'err_wrong_url', 'Wrong URL', 'main'),
(22, 'err_no_cats', 'No Categories', 'main'),
(552, 'the_details', 'Details', 'cp'),
(24, 'pages', 'Pages', 'main'),
(26, 'the_writer', 'Writer', 'main'),
(27, 'the_news_archive', 'News Archive', 'main'),
(553, 'del_product_cat_warning', 'Deleting this category will delete all sub categories and products , Continue ?', 'cp'),
(551, 'the_price', 'The Price', 'main'),
(30, 'vote_select', 'Vote', 'main'),
(31, 'vote_do', 'Vote', 'main'),
(32, 'send2friend_subject', 'Invitation from Your Friend', 'main'),
(33, 'send2friend_done', 'Invitation sent to your Friend', 'main'),
(34, 'your_name', 'Your Name', 'main'),
(35, 'your_email', 'Your Email', 'main'),
(36, 'your_friend_email', 'Friend Email', 'main'),
(37, 'send', 'Send', 'main'),
(38, 'err_vote_expire_hours', 'Sorry, You can vote Every {vote_expire_hours} Hour', 'main'),
(39, 'add2favorite', 'Add to Favorite', 'main'),
(40, 'add2fav_success', 'Added to Favorite Successfully', 'main'),
(41, 'register_closed', 'Sorry , Registration is closed', 'main'),
(42, 'no_news', 'No News', 'main'),
(570, 'cart_update', 'Update the Cart', 'main'),
(571, 'cart_clear', 'Clear the Cart', 'main'),
(44, 'the_phrases', 'Phrases', 'cp'),
(45, 'welcome_to_cp', 'Welcome to Control Panel', 'cp'),
(46, 'php_version', 'PHP Version', 'cp'),
(47, 'mysql_version', 'MySQL Version', 'cp'),
(48, 'zend_version', 'Zend Optimizer Version', 'cp'),
(49, 'the_version', 'Version', 'cp'),
(50, 'cp_available', 'Available', 'cp'),
(51, 'cp_not_available', 'Not Available', 'cp'),
(52, 'gd_library', 'GD Library', 'cp'),
(53, 'gd_install_required', 'Gd library is not installed , without it script will not work fine.', 'cp'),
(54, 'cp_addons', 'Plugins', 'cp'),
(55, 'no_addons', 'No Plugins', 'cp'),
(56, 'edit', 'Edit', 'cp'),
(57, 'register', 'Register', 'main'),
(58, 'register_email_exists', 'Email Already Exists', 'main'),
(59, 'register_user_exists', 'Sorry , Username {username} Already Exists', 'main'),
(60, 'reg_complete', 'Registration Complete Successfully', 'main'),
(548, 'the_products', 'The Products', 'main'),
(61, 'err_fileds_not_complete', 'Please Fill All Fields', 'main'),
(62, 'err_passwords_not_match', 'Password is not match it', 'main'),
(63, 'email', 'Email', 'main'),
(64, 'username', 'Username', 'main'),
(65, 'password', 'Password', 'main'),
(66, 'cp_login_do', 'Login', 'cp'),
(67, 'cp_username', 'Username', 'cp'),
(68, 'cp_password', 'Password', 'cp'),
(69, 'the_content_type', 'Content Type', 'cp'),
(70, 'the_url', 'URL', 'cp'),
(71, 'bnr_appearance_places', 'Appearance Places', 'cp'),
(72, 'bnr_appearance_pages', 'Appearance Pages', 'cp'),
(73, 'add_after_menu_number', 'Add After Menu #', 'cp'),
(74, 'login_do', 'Login', 'cp'),
(75, 'bnr_ctype_code', 'Code', 'cp'),
(76, 'bnr_ctype_img', 'Image / URL', 'cp'),
(77, 'the_code', 'Code', 'cp'),
(78, 'bnr_open', 'Site-Open', 'cp'),
(79, 'bnr_close', 'Site-Close', 'cp'),
(80, 'bnr_menu', 'Menu', 'cp'),
(81, 'bnr_header', 'Header', 'cp'),
(82, 'bnr_footer', 'Footer', 'cp'),
(83, 'bnr_menu_pos', 'on', 'cp'),
(84, 'the_left', 'The Left', 'cp'),
(85, 'the_center', 'The Center', 'cp'),
(86, 'the_right', 'The Rigth', 'cp'),
(87, 'bnr_the_menu', 'The Menu', 'cp'),
(88, 'bnr_the_visits', 'Visits', 'cp'),
(89, 'bnr_appearance_count', 'Appearance Count', 'cp'),
(90, 'add_button', 'Add', 'cp'),
(91, 'the_order', 'Order', 'cp'),
(92, 'the_image', 'Picture', 'cp'),
(93, 'the_title', 'Title', 'cp'),
(94, 'delete', 'Delete', 'cp'),
(95, 'pages_lang', 'Pages Language', 'cp'),
(96, 'pages_encoding', 'Pages Encoding', 'cp'),
(97, 'cp_enable_browsing', 'Enable Browsing', 'cp'),
(98, 'cp_opened', 'Opened', 'cp'),
(99, 'cp_closed', 'Closed', 'cp'),
(100, 'cp_browsing_closing_msg', 'Browsing Close Message', 'cp'),
(101, 'site_closed_for_visitors', 'Website Closed For Visitors', 'main'),
(102, 'cp_mailing_sending_to', 'Sending to', 'cp'),
(103, 'cp_send_as', 'Send As', 'cp'),
(104, 'cp_as_email', 'Email', 'cp'),
(105, 'next_page', 'Next Page', 'cp'),
(106, 'failed', 'Failed', 'cp'),
(107, 'cp_as_pm', 'Personal Message', 'cp'),
(108, 'cp_send_to', 'Send To', 'cp'),
(109, 'all_members', 'All Clients', 'cp'),
(110, 'one_member', 'One Client', 'cp'),
(111, 'sender_name', 'Sender Name', 'cp'),
(112, 'sender_email', 'Sender Email', 'cp'),
(113, 'msg_type', 'Message Type', 'cp'),
(114, 'msg_encoding', 'Message Encoding', 'cp'),
(115, 'msg_subject', 'Message Subject', 'cp'),
(116, 'start_from', 'Start From', 'cp'),
(117, 'mailing_emails_perpage', 'Emails Per Page', 'cp'),
(118, 'auto_pages_redirection', 'Auto Pages Redirection', 'cp'),
(119, 'cp_url_fopen_disabled_msg', 'your server settings does not allow you to import file from external url', 'cp'),
(120, 'err_url_x_invalid', 'Url : {url} is invalid', 'cp'),
(121, 'local_file_uploader', 'Local File', 'cp'),
(122, 'external_file_uploader', 'External File', 'cp'),
(123, 'cp_photo_resize_width', 'width', 'cp'),
(124, 'cp_photo_resize_hieght', 'hieght', 'cp'),
(125, 'view', 'View', 'cp'),
(126, 'members_mailing', 'Clients Mailing', 'cp'),
(127, 'yes', 'Yes', 'main'),
(128, 'no', 'No', 'main'),
(129, 'cp_mng_members', 'Clients Managment', 'cp'),
(130, 'members_custom_fields', 'Clients Custom Fields', 'cp'),
(131, 'cp_members_remote_db', 'Remote Database', 'cp'),
(132, 'the_members', 'Clients', 'cp'),
(133, 'cp_add_new_template', 'Add New Template', 'cp'),
(134, 'the_description', 'Description', 'cp'),
(135, 'cp_edit_templates', 'Edit Templates', 'cp'),
(136, 'main_page', 'Main Page', 'cp'),
(137, 'the_templates', 'Templates', 'cp'),
(138, 'style_settings', 'Settings', 'cp'),
(139, 'add_style', 'Add new Styles', 'cp'),
(140, 'style_selectable', 'Selectable', 'cp'),
(141, 'template_name', 'Template Name', 'cp'),
(142, 'template_description', 'Template Description', 'cp'),
(143, 'add_new_template', 'Add New Template', 'cp'),
(144, 'are_you_sure', 'Are You Sure ?', 'cp'),
(145, 'the_database', 'The Database', 'cp'),
(146, 'backup', 'Backup', 'cp'),
(147, 'db_repair_tables_do', 'Repair Tables', 'cp'),
(148, 'cp_db_backup_do', 'Do Backup now', 'cp'),
(149, 'the_file_path', 'File Path', 'cp'),
(150, 'db_backup_saveto_server', 'Save on Your website space', 'cp'),
(151, 'db_backup_saveto_pc', 'Save on Your Computer', 'cp'),
(152, 'cp_db_backup', 'Database Backup', 'cp'),
(153, 'the_size', 'Size', 'cp'),
(154, 'the_table', 'Table', 'cp'),
(155, 'the_status', 'Status', 'cp'),
(156, 'please_select_tables_to_rapair', 'Please Select tables that you want to repair', 'cp'),
(157, 'cp_repairing_table', 'Repairing ', 'cp'),
(158, 'done', 'Done', 'cp'),
(159, 'cp_db_check_repair', 'Check / Repair', 'cp'),
(160, 'backup_done_successfully', 'Backup Done Successfully', 'cp'),
(161, 'the_search', 'Search', 'cp'),
(162, 'members_count', 'Clients', 'cp'),
(163, 'cp_remote_members_db', 'Remote Clients Database', 'cp'),
(164, 'use_remote_db', 'Use Remote Database', 'cp'),
(165, 'db_host', 'Database Host', 'cp'),
(166, 'db_name', 'Database Name', 'cp'),
(167, 'db_username', 'Database Username', 'cp'),
(168, 'members_table', 'Clients Table Name', 'cp'),
(169, 'note', 'Note', 'cp'),
(170, 'members_remote_db_wizzard_note', 'when you use a new Clients remote database you have to run Remote Database Wizzard to check if the database is compatible with script and setup it', 'cp'),
(171, 'members_remote_db_wizzard', 'Remote Database Wizard', 'cp'),
(172, 'chng_field_type_success', 'Field type changed successfully', 'cp'),
(173, 'chng_field_type_failed', 'unable to change field type , please change it manually from your database admin application', 'cp'),
(174, 'add_field_failed', 'unable to add field , please add it manually from your database admin application', 'cp'),
(175, 'add_field_success', 'Field added successfully', 'cp'),
(176, 'members_remote_db_compatible', 'Remote Database is compatible', 'cp'),
(177, 'members_remote_db_uncompatible', 'the database is not compatible with script, please check and correct the errors and run the wizzard again', 'cp'),
(178, 'wrong_remote_db_name', 'Wrong Remote Database name', 'cp'),
(179, 'wrong_remote_db_connect_info', 'Error while connecting to remote database , please check connection info', 'cp'),
(180, 'members_remote_db_disabled', 'System is disabled', 'cp'),
(181, 'no_members_custom_fields', 'No Custom Fields', 'cp'),
(182, 'add_member_custom_field', 'Add New Field', 'cp'),
(183, 'the_type', 'Type', 'cp'),
(184, 'textbox', 'Text box', 'cp'),
(185, 'textarea', 'Text Area', 'cp'),
(186, 'select_menu', 'Select Menu', 'cp'),
(187, 'radio_button', 'Radio Button', 'cp'),
(188, 'checkbox', 'Checkbox', 'cp'),
(189, 'default_value', 'Default Value', 'cp'),
(190, 'put_every_option_in_sep_line', 'For Options , put every option in new line', 'cp'),
(191, 'required', 'Required', 'cp'),
(192, 'addition_style', 'Field Style', 'cp'),
(193, 'addition_fields', 'Addition Fields', 'cp'),
(194, 'this_member_not_exists', 'This Client is not exists', 'cp'),
(195, 'members_local_db_clean_wizzard', 'Local Database Clean Wizard', 'cp'),
(196, 'members_local_db_clean_note', 'When you use a remote or local database , some clients data like private messages , favorites , custom fields , etc..  is stored on local database , so it', 'cp'),
(197, 'members_local_db_clean_description', 'Wizard will delete any clients data as listed , please make sure that tables does not containing any important data then click on process button', 'cp'),
(198, 'members_msgs_table', 'Clients Private Messages Table', 'cp'),
(199, 'members_favorite_table', 'Clients Favorite files Table', 'cp'),
(200, 'members_custom_fields_table', 'Clients Custom Fields Table', 'cp'),
(201, 'members_confirmations_table', 'Clients Confirmations Table', 'cp'),
(202, 'process_done_successfully', 'Process Done Successfully', 'cp'),
(274, 'from', 'From', 'cp'),
(275, 'plz_enter_username_and_pwd', 'Please Enter the username and Password', 'main'),
(204, 'pwd_rest_request_msg_subject', 'Rest Password Request', 'cp'),
(205, 'rest_pwd_request_msg_sent', 'changing password confirmation email sent to you', 'cp'),
(206, 'pwd_rest_done_msg_subject', 'Your New Password !', 'cp'),
(207, 'pwd_rest_done', 'Your password changed and sent to your email', 'cp'),
(208, 'security_code', 'Security Code', 'cp'),
(209, 'email_activation_msg_subject', 'Email Activation', 'cp'),
(210, 'upload_file', 'Upload File', 'cp'),
(211, 'search_do', 'Search', 'cp'),
(212, 'birth', 'Birth', 'main'),
(213, 'country', 'Country', 'main'),
(214, 'select_from_menu', 'Select From Menu', 'main'),
(215, 'register_do', 'Register', 'main'),
(216, 'registered_before', 'You are already registered', 'main'),
(217, 'click_here', 'Click Here', 'main'),
(218, 'forgot_pass', 'Forgot your Password?', 'main'),
(219, 'login_info_sent', 'Login info sent to your email', 'main'),
(220, 'email_not_exists', 'Sorry , This Email is not Exists', 'main'),
(221, 'continue', 'Continue', 'main'),
(222, 'active_account', 'Account Activation', 'main'),
(223, 'active_acc_succ', 'Your Account Activated Successfullu', 'main'),
(224, 'active_acc_err', 'Sorry , Wrong URL or Account Already Activated', 'main'),
(225, 'login', 'Login', 'main'),
(226, 'newuser', 'New Member ?', 'main'),
(227, 'err_function_usage_denied', 'Error : You can', 'main'),
(228, 'err_emails_not_match', 'Email is not matching it', 'main'),
(229, 'email_confirm', 'Email Confirm', 'main'),
(230, 'err_sec_code_not_valid', 'Security code is not valid', 'main'),
(231, 'registration', 'Registration', 'cp'),
(232, 'as_every_cat_settings', 'as Every Category Settings', 'cp'),
(233, 'enabled_for_all', 'Enabled For All', 'cp'),
(235, 'security_code_in_registration', 'Registration Security Code', 'cp'),
(236, 'auto_email_activate', 'Auto Email Activation', 'cp'),
(237, 'username_min_letters', 'username Min Letters', 'cp'),
(238, 'username_exludes', 'username Excludes', 'cp'),
(239, 'emails_msgs_default_type', 'Emails Default Messages Type', 'cp'),
(240, 'emails_msgs_default_encoding', 'Emails Default Messages Encoding', 'cp'),
(241, 'leave_blank_to_use_site_encoding', 'leave it blank to use site encoding', 'cp'),
(242, 'uploader_system', 'Uploader System', 'cp'),
(243, 'disable_uploader_msg', 'Uploader Disable Message', 'cp'),
(244, 'uploader_path', 'Uploading Path', 'cp'),
(245, 'uploader_allowed_types', 'Allowed Types', 'cp'),
(246, 'enabled', 'Enabled', 'cp'),
(247, 'disabled', 'Disable', 'cp'),
(248, 'password_confirm', 'Password Confirm', 'main'),
(249, 'err_username_min_letters', 'Error , username lenght is not meeting the minimum letters lenght', 'main'),
(250, 'err_email_not_valid', 'invalid Email address', 'main'),
(251, 'err_username_not_allowed', 'Username not allowed , please select another one', 'main'),
(252, 'reg_complete_need_activation', 'Registration done , please check your email for activation message.', 'main'),
(253, 'req_addition_info', 'Required Addition Info', 'main'),
(254, 'not_req_addition_info', 'Not Required Addition Info', 'main'),
(255, 'your_email_changed_successfully', 'Your Email Changed Successfully', 'main'),
(256, 'this_account_already_activated', 'This Account Already Activated', 'main'),
(257, 'closed_account_cannot_activate', 'Sorry, This is Closed Account , you can not Activate it', 'main'),
(258, 'activation_msg_sent_successfully', 'Activation Message Sent Successfully', 'main'),
(259, 'register_date', 'Registration Date', 'cp'),
(260, 'last_login', 'Last Login', 'cp'),
(261, 'client_deleted_successfully', 'Client Deleted Successfully', 'cp'),
(262, 'member_added_successfully', 'Client Added Successfully', 'cp'),
(263, 'please_fill_all_fields', 'Please Fill All Fields', 'cp'),
(264, 'member_edited_successfully', 'Client Edited successfully', 'cp'),
(265, 'add_member', 'Add Client', 'cp'),
(266, 'records_perpage', 'Records Per Page', 'cp'),
(267, 'member_edit', 'Edit Client', 'cp'),
(268, 'member_acc_type', 'Account type', 'cp'),
(269, 'send_msg_to_client', 'Send Message to Client', 'cp'),
(270, 'acc_type_not_activated', 'Not Activated', 'cp'),
(271, 'acc_type_activated', 'Activated', 'cp'),
(272, 'acc_type_closed', 'Closed', 'cp'),
(273, 'leave_blank_for_no_change', 'Leave blank to not change', 'cp'),
(276, 'this_account_closed_cant_login', 'Sorrry , This Account is Closed', 'main'),
(277, 'this_account_not_activated', 'Sorry , This account is not activated', 'main'),
(278, 'chng_email_msg_subject', 'Changing email Confirm', 'main'),
(279, 'resend_activation_msg', 'resend Activation Message', 'main'),
(280, 'invalid_pwd', 'Sorry , Invalid Password', 'main'),
(281, 'invalid_username', 'Sorry , Invalid Username', 'main'),
(282, 'usercp_menu', 'Member Menu', 'main'),
(283, 'usercp_welcome_msg', 'Welcome {username} to Member Control Panel', 'main'),
(284, 'cp_hooks_fix_order', 'Fix Order', 'cp'),
(285, 'cp_hooks', 'Plugins / Hooks', 'cp'),
(286, 'no_hooks', 'No Hooks', 'cp'),
(287, 'add', 'Add', 'cp'),
(288, 'the_place', 'The Place', 'cp'),
(289, 'the_options', 'Options', 'cp'),
(290, 'the_default_template', 'Default Template', 'cp'),
(643, 'products_thumb_width', 'Products thumb''s width', 'cp'),
(292, 'the_news', 'News', 'cp'),
(293, 'the_votes', 'Votes', 'cp'),
(294, 'the_statics', 'Statics', 'cp'),
(295, 'appearance_places', 'Appearance Places', 'cp'),
(296, 'the_blocks', 'Blocks', 'cp'),
(297, 'the_position', 'Position', 'cp'),
(298, 'right', 'Right', 'cp'),
(299, 'center', 'Center', 'cp'),
(300, 'left', 'Left', 'cp'),
(301, 'the_template', 'Template', 'cp'),
(302, 'to_up', 'To up', 'cp'),
(303, 'to_down', 'To down', 'cp'),
(304, 'enable', 'Enable', 'cp'),
(305, 'disable', 'Disable', 'cp'),
(306, 'cp_blocks_fix_order', 'Fix Order', 'cp'),
(307, 'cp_no_blocks', 'No Blocks', 'cp'),
(308, 'the_content', 'Content', 'cp'),
(309, 'logout', 'Logout', 'cp'),
(310, 'the_settings', 'Settings', 'cp'),
(311, 'do_button', 'Process', 'cp'),
(312, 'news_add', 'Add News', 'cp'),
(313, 'news_short_content', 'Short Details', 'cp'),
(314, 'auto_short_content_create', 'Auto Short details Create', 'cp'),
(315, 'the_date', 'Date', 'main'),
(316, 'all', 'All', 'main'),
(317, 'view_do', 'View', 'main'),
(318, 'os_and_browsers_statics', 'OS & Browsers Statics', 'cp'),
(319, 'visitors_hits_statics', 'Visitors Hits Statics', 'cp'),
(320, 'online_visitors_statics', 'Online Visitors Statics', 'cp'),
(321, 'default_style', 'Default Style', 'cp'),
(322, 'search_min_letters', 'Search Minimum Letters', 'cp'),
(323, 'sorry_search_disabled', 'Sorry , Search Disabled', 'main'),
(324, 'uploader_title', 'Uploader', 'cp'),
(325, 'pixel', 'Pixel', 'cp'),
(326, 'this_filetype_not_allowed', 'File type not allowed', 'cp'),
(327, 'the_file', 'File', 'cp'),
(328, 'auto_photos_resize', 'Auto Pictures Resize', 'cp'),
(329, 'upload_file_do', 'Upload', 'cp'),
(330, 'allowed_filetypes', 'Allowed Types', 'cp'),
(331, 'please_login_first', 'Please Login First', 'cp'),
(332, 'uploader_thumb_width', 'Uploader - Thumb Max Width', 'cp'),
(333, 'uploader_thumb_hieght', 'Uploader - Thumb Max Hieght', 'cp'),
(334, 'fixed', 'Fixed', 'cp'),
(335, 'send2friend_failed', 'Error whie sending , please try again later', 'main'),
(336, 'invalid_from_or_to_email', 'Invalid From or To Email Address', 'main'),
(339, 'urls_fields_add', 'Add new Field', 'cp'),
(340, 'access_denied', 'Access Denied', 'cp'),
(642, 'notify_client_when_order_status_change', 'Notify Client by Email when Order Status Changed', 'cp'),
(342, 'the_cat', 'Category', 'cp'),
(641, 'show_paid_option', 'Show Paid Option', 'cp'),
(347, 'no_new_files', 'No New Files', 'cp'),
(348, 'err_autosearch_folder_not_exists', 'Error, Auto Search folder is invalid', 'cp'),
(349, 'auto_search', 'Auto Search', 'cp'),
(640, 'orders_perpage', 'Order per Page', 'cp'),
(639, 'images_folder', 'Images Folder', 'cp'),
(638, 'edit_templates', 'Edit Templates', 'cp'),
(353, 'the_banners', 'Banners', 'cp'),
(354, 'users_and_permissions', 'Users & Permissions', 'cp'),
(355, 'permissions_manage', 'Permissions Manage', 'cp'),
(356, 'cp_sections_permissions', 'Sections Permissions', 'cp'),
(637, 'find_client_orders', 'Find Client Orders', 'cp'),
(359, 'cp_err_username_exists', 'Error , Username already Exists', 'cp'),
(360, 'cp_plz_enter_usr_pwd', 'Please Enter username and password', 'cp'),
(361, 'cp_edit_user_success', 'Edit User Done Successfully', 'cp'),
(362, 'cp_add_user', 'Add User', 'cp'),
(363, 'cp_email', 'Email', 'cp'),
(364, 'cp_user_group', 'Group', 'cp'),
(365, 'cp_user_admin', 'Administrator', 'cp'),
(366, 'cp_user_mod', 'Moderator', 'cp'),
(367, 'the_users', 'Users', 'cp'),
(368, 'edit_personal_acc_only', 'Sorry , You can only edit your account info', 'cp'),
(369, 'click_here_to_edit_ur_account', 'To edit your account click here', 'cp'),
(372, 'the_pages', 'Pages', 'cp'),
(373, 'pages_add', 'Add New Page', 'cp'),
(374, 'no_pages', 'No Pages', 'cp'),
(375, 'err_cat_access_denied', 'Category Access Denied', 'cp'),
(636, 'you_can_edit_this_values_from_config_file', 'You can edit this values from config.php file', 'cp'),
(378, 'no_data', 'No Data', 'cp'),
(635, 'shipping_methods', 'Shipping Methods', 'cp'),
(380, 'field_style', 'Field Style', 'cp'),
(644, 'products_thumb_height', 'Products thumb''s height', 'cp'),
(382, 'asc', 'ASC', 'cp'),
(383, 'desc', 'DESC', 'cp'),
(634, 'payment_methods', 'Payment Methods', 'cp'),
(386, 'the_most_voted', 'Most Voted', 'cp'),
(633, 'payment_and_shipping', 'Payment and Shipping', 'cp'),
(632, 'the_products_and_cats', 'Products & Categories', 'cp'),
(631, 'products_fields', 'Features & Details', 'cp'),
(630, 'store_field_add', 'Add', 'cp'),
(628, 'new', 'New', 'main'),
(629, 'features', 'Features', 'main'),
(569, 'delete_from_cart', 'Delete From Cart', 'main'),
(673, 'fields_options_add_note', 'you can edit options by click on edit button after adding the field', 'cp'),
(396, 'printable_copy', 'Print', 'main'),
(627, 'kg', 'Kg', 'main'),
(398, 'singers_other_letters', 'Other', 'main'),
(399, 'the_favorite', 'Favorite', 'main'),
(400, 'no_files', 'No Files', 'main'),
(401, 'send_new_msg', 'Send New Message', 'main'),
(402, 'the_messages', 'Messages', 'main'),
(403, 'used_messages', 'Used Messages', 'main'),
(404, 'pm_box_full_warning', 'Warning : Your Box is Full and you can', 'main'),
(405, 'no_messages', 'No Messages', 'main'),
(406, 'the_sender', 'Sender', 'main'),
(407, 'the_subject', 'Subject', 'main'),
(408, 'reply', 'Reply', 'main'),
(409, 'err_sendto_pm_box_full', 'Error, Box that you trying to sent to is full.', 'main'),
(410, 'pm_sent_successfully', 'Your Message Sent Successfully', 'main'),
(411, 'err_sendto_username_invalid', 'Error , Receiver username is invalid', 'main'),
(412, 'the_message', 'Message', 'main'),
(413, 'chng_email_conf_msg_sent', 'your new email confirmation message sent to your email', 'main'),
(414, 'your_profile_updated_successfully', 'Your Profile Updated Successfully', 'main'),
(415, 'the_profile', 'Profile', 'main'),
(417, 'err_wrong_uploader_folder', 'Wrong Uploader Folder', 'cp'),
(418, 'register_email_exists2', 'if this is your email and you forgot the password ', 'cp'),
(419, 'the_statics_and_counters', 'Statics & Counters', 'cp'),
(420, 'cp_visitors_statics', 'Visitors Statics', 'cp'),
(421, 'cp_counters_start_date', 'Counters start Date', 'cp'),
(422, 'cp_total_visits', 'Total Visits', 'cp'),
(423, 'the_hour', 'Hour', 'cp'),
(424, 'operating_systems', 'Operating Systems', 'main'),
(425, 'the_browsers', 'Browser', 'main'),
(426, 'monthly_statics_for', 'Monthly Statics for ', 'main'),
(427, 'daily_statics_for', 'Daily Statics for', 'main'),
(428, 'the_year', 'Year', 'main'),
(429, 'the_month', 'Month', 'main'),
(430, 'right_to_left', 'Right to Left', 'cp'),
(431, 'left_to_right', 'Left to Right', 'cp'),
(432, 'page_dir', 'Page Direction', 'cp'),
(433, 'mailing_email', 'Mailing Email', 'cp'),
(434, 'copyrights_sitename', 'Copyrights Site Name', 'cp'),
(435, 'section_name', 'Section Name', 'cp'),
(436, 'site_name', 'Site Name', 'cp'),
(437, 'page_keywords', 'Keywords', 'cp'),
(438, 'votes_expire_time', 'Seperation time between votes', 'cp'),
(439, 'hour', 'Hour', 'cp'),
(626, 'the_weight', 'Weight', 'main'),
(625, 'not_available_now', 'Not Available Now', 'main'),
(444, 'bnr_views', 'View', 'cp'),
(445, 'bnr_visits', 'Visit', 'cp'),
(621, 'update', 'Update', 'main'),
(622, 'orderby', 'Sort by', 'main'),
(623, 'remove_from_fav', 'Remove from Favorites', 'main'),
(620, 'to', 'To', 'main'),
(619, 'search_in_subcats', 'Search in Sub-Categories', 'main'),
(618, 'enlarge_pic', 'Click to Enlarge', 'main'),
(617, 'product_photos', 'Product Photos', 'main'),
(616, 'not_selected', 'Not Selected', 'main'),
(615, 'availability', 'Availability', 'main'),
(614, 'orders_status', 'Orders Status', 'main'),
(613, 'the_orders', 'Orders', 'main'),
(456, 'the_cats', 'Categories', 'cp'),
(612, 'product_details', 'Product Details', 'main'),
(611, 'browse_products', 'Browse Products', 'cp'),
(459, 'add_cat', 'Add Category', 'cp'),
(609, 'the_addresses', 'The Addresss', 'main'),
(610, 'my_addresses', 'My Addresses', 'main'),
(461, 'default', 'Default', 'cp'),
(462, 'view_page', 'View Page', 'cp'),
(463, 'vote_add', 'Add new Vote', 'cp'),
(464, 'set_default', 'Set as Default', 'cp'),
(465, 'edit_or_options', 'Edit / Options', 'cp'),
(466, 'add_options', 'Add Options', 'cp'),
(568, 'hot_items', 'Hot Items', 'cp'),
(468, 'images_cells_count', 'Images Cells Count', 'cp'),
(469, 'news_perpage', 'News Per Page', 'cp'),
(470, 'back_to_cats', 'Back to Categories', 'cp'),
(608, 'my_orders', 'My Orders', 'main'),
(607, 'no_orders', 'No Orders', 'main'),
(606, 'no_saved_addresses', 'No Saved Addresses', 'main'),
(474, 'move_from', 'Move From', 'cp'),
(475, 'move_to', 'Move to', 'cp'),
(605, 'address_title', 'Address Title', 'main'),
(477, 'next', 'Next', 'cp'),
(480, 'move_do', 'Move', 'cp'),
(604, 'redirection_msg', 'Redirecting , if your browser not support redirecting', 'main'),
(603, 'checkout', 'Checkout', 'main'),
(602, 'no_payment_gateways_available', 'No Payment Gateways Available', 'main'),
(485, 'select_all', 'Check All', 'cp'),
(486, 'select_none', 'Uncheck All', 'cp'),
(487, 'change_comment', 'Change Comment', 'cp'),
(601, 'payment_gateways', 'Payment Gateways', 'main'),
(600, 'related_products', 'Related Products', 'main'),
(599, 'count', 'Qty', 'main'),
(598, 'the_cart', 'Shopping Cart', 'main'),
(493, 'without_comment', 'Without Comment', 'cp'),
(494, 'the_comment', 'Comment', 'cp'),
(495, 'fields_count', 'Fields Count', 'cp'),
(597, 'prev_votes', 'Prev. Votes', 'main'),
(596, 'no_options', 'No Options', 'main'),
(500, 'users_count', 'Users', 'cp'),
(501, 'show_sitename_in_subpages', 'Show Site name in sub-pages', 'cp'),
(502, 'show_section_name_in_subpages', 'Show Section name in sub-pages', 'cp'),
(595, 'bill_payment', 'Invoice Payment', 'main'),
(594, 'not_available', 'Not Available', 'main'),
(593, 'order_status', 'Order Status', 'main'),
(506, 'msgs_count_limit', 'Member Messages Limit', 'cp'),
(507, 'message', 'Message', 'cp'),
(592, 'paid', 'Paid', 'main'),
(591, 'order_date', 'Order Date', 'main'),
(590, 'order_info', 'Order Info', 'main'),
(589, 'the_invoice', 'The Invoice', 'main'),
(588, 'order_send', 'Send', 'main'),
(587, 'payment_method', 'Payment Method', 'main'),
(586, 'shipping_method', 'Shipping Method', 'main'),
(516, 'ram_banner_width', 'Banners window width', 'cp'),
(517, 'ram_banner_height', 'Banners window height', 'cp'),
(585, 'shipping_name', 'Name', 'main'),
(584, 'shipping_address', 'Shipping Address', 'main'),
(583, 'not_saved', 'Not Saved', 'main'),
(582, 'saved_address', 'Saved Address', 'main'),
(581, 'billing_address', 'Billing Address', 'main'),
(580, 'telephone', 'Tel.', 'main'),
(579, 'the_address', 'Address', 'main'),
(578, 'city', 'City', 'main'),
(577, 'billing_name', 'Name', 'main'),
(576, 'add_new_address', 'Add New Address', 'main'),
(575, 'the_count', 'Qty', 'main'),
(574, 'the_items', 'Items', 'main'),
(573, 'the_total', 'Total', 'main'),
(572, 'cart_is_empty', 'Cart is Empty', 'main'),
(532, 'err_invalid_id', '<b>Error : </b> Invalid ID', 'cp'),
(533, 'the_id', 'ID', 'cp'),
(534, 'without_title', 'No Title', 'cp'),
(535, 'cp_rest_counters', 'Rest Counters', 'cp'),
(536, 'cp_rest_counters_do', 'Rest Counters', 'cp'),
(537, 'visitors_statics_rest_done', 'Rest Counters Done', 'cp'),
(538, 'cp_no_phrases', 'No Phrases', 'cp'),
(539, 'cp_no_templates', 'No Templates', 'cp'),
(540, 'cp_invalid_pwd', 'invalid password', 'cp'),
(541, 'cp_invalid_username', 'invalid username', 'cp'),
(542, 'cp_welcome_msg', 'Welcome {username}', 'cp'),
(543, 'cp_statics', 'Statics', 'cp'),
(544, 'search', 'Search', 'cp'),
(545, 'forgot_pwd_msg_subject', 'Recover your password', 'cp'),
(546, 'without_selection', 'None', 'cp'),
(547, 'create_main_user', 'Create Main User', 'cp'),
(549, 'no_products', 'No Products', 'main'),
(561, 'tabbed_to', 'Tabbed To', 'cp'),
(562, 'without_tabbed_menu', 'Not Tabbed', 'cp'),
(563, 'prev', 'Prev.', 'main'),
(564, 'offers_menu', 'Offers Menu', 'main'),
(565, 'products_default_orderby', 'Products default Sort', 'cp'),
(566, 'visitors_can_sort_products', 'Visitors can Sort Products', 'cp'),
(645, 'show_prev_votes', 'Show Prev. Votes', 'cp'),
(567, 'the_clients', 'Clients', 'cp'),
(646, 'max_count', 'Max Count', 'cp'),
(647, 'random', 'Random', 'cp'),
(648, 'cats_permissions', 'Categories Permissions', 'cp'),
(649, 'cats_permissions_note', 'You can edit Categories Permission by click on edit button for each Category', 'cp'),
(650, 'store_fields_note', 'You can choose Features & Details for each category by edit button for each category', 'cp'),
(651, 'the_orders_count', 'Orders count', 'cp'),
(652, 'the_order_number', 'Order #', 'cp'),
(654, 'client_account', 'Client Acc.', 'cp'),
(655, 'orders_seach', 'Orders Search', 'cp'),
(656, 'other', 'Other', 'main'),
(657, 'status_change_notify_sent', 'Notification Sent to Client', 'cp'),
(658, 'status_change_notify_failed', 'Failed to Send Notification to Client', 'cp'),
(659, 'order_number_x', 'Order #', 'cp'),
(660, 'order_delete', 'Order Delete', 'cp'),
(661, 'the_total_price', 'Total Price', 'cp'),
(662, 'update_data', 'Update Data', 'cp'),
(663, 'cannot_disable_default_status', 'Can not Disable Default Status', 'cp'),
(664, 'cannot_delete_default_status', 'Can not Delete Default Status', 'cp'),
(665, 'in_orders_without_shipping', 'Orders without Shipping', 'cp'),
(666, 'in_orders_with_shipping', 'Orders with Shipping', 'cp'),
(667, 'text_color', 'Text Color', 'cp'),
(668, 'show_payment_options', 'Show Payment Options', 'cp'),
(669, 'sending_form_code', 'Sending Form Code', 'cp'),
(670, 'is_gateway', 'is Gateway ?', 'cp'),
(671, 'short_description', 'Short Description', 'cp'),
(672, 'fields_search_menu', 'Search Menu', 'cp'),
(674, 'options_edit', 'Edit Options', 'cp'),
(675, 'the_value', 'Value', 'cp'),
(676, 'without_main_cat', 'without main Category', 'cp'),
(677, 'move_the_products', 'Move Products', 'cp'),
(678, 'please_select_products_first', 'Please Select Products first', 'cp'),
(679, 'move_the_cats', 'Move Categories', 'cp'),
(680, 'please_select_cats_first', 'Please Select Categories first', 'cp'),
(681, 'err_products_not_selected', '<b> Error : </b> No products Selected', 'cp'),
(682, 'err_invalid_cat_id', '<b> Error : </b> Invalid Category ID', 'cp'),
(683, 'err_cats_not_selected', '<b> Error : </b> No Categories Selected', 'cp'),
(684, 'move', 'Move', 'cp'),
(685, 'add_to_hot_items', 'Add to Hot Items', 'cp'),
(686, 'the_moderators', 'Moderators', 'cp'),
(687, 'page_custom_info', 'Page Custom Info', 'cp'),
(688, 'the_page_keywords', 'Page Keywords', 'cp'),
(689, 'products_thumb_fixed', 'Fixed Size', 'cp'),
(690, 'add_product', 'Add Products', 'cp'),
(691, 'can_shipping', 'Can Shipping', 'cp'),
(692, 'manage_product_photos', 'Manage Product Photos', 'cp'),
(693, 'photos_count', 'Photos Count', 'cp'),
(694, 'product_add_photos_note', 'Edit the product after adding to manage Photos', 'cp'),
(695, 'add_photos', 'Add Photos', 'cp'),
(696, 'no_photos', 'No Photos', 'cp'),
(697, 'no_moderators', 'No Moderators', 'cp'),
(698, 'available', 'Available', 'cp'),
(699, 'pay_now', 'Pay Now', 'main'),
(700, 'products_count', 'Products Count', '1'),
(701, 'clients_count', 'Clients Count', '1');

-- --------------------------------------------------------

--
-- Table structure for table `store_phrases_cats`
--

CREATE TABLE IF NOT EXISTS `store_phrases_cats` (
  `id` text NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY  (`id`(20))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_phrases_cats`
--

INSERT INTO `store_phrases_cats` (`id`, `name`) VALUES
('main', 'System / General'),
('cp', 'Control Panel');

-- --------------------------------------------------------

--
-- Table structure for table `store_products_cats`
--

CREATE TABLE IF NOT EXISTS `store_products_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  `img` text NOT NULL,
  `fields` text NOT NULL,
  `users` text NOT NULL,
  `shipping_methods` text NOT NULL,
  `page_title` text NOT NULL,
  `page_description` text NOT NULL,
  `page_keywords` text NOT NULL,
  `path` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `store_products_cats`
--

INSERT INTO `store_products_cats` (`id`, `name`, `ord`, `active`, `cat`, `img`, `fields`, `users`, `shipping_methods`, `page_title`, `page_description`, `page_keywords`, `path`) VALUES
(2, 'Gifts &amp; Accessories', 1, 1, 0, 'data/products/gifts.png', '', '', '1', '', '', '', '2,0'),
(27, 'Mobile Phones', 1, 1, 1, 'data/products/mobiles.png', '5,9', '', '', '', '', '', '27,1,0'),
(29, 'Games', 0, 1, 28, 'data/products/games.png', '19', '', '', '', '', '', '29,28,0'),
(1, 'Electronics', 0, 1, 0, 'data/products/electronics.png', '', '2', '1,2,3', '', '', '', '1,0'),
(4, 'Televisions', 3, 1, 1, 'data/products/plasma.png', '', '', '', '', '', '', '4,1,0'),
(5, 'Game Consoles', 2, 1, 1, 'data/products/games_console.png', '', '', '', '', '', '', '5,1,0'),
(28, 'Games &amp; Movies', 3, 1, 0, 'data/products/dvd.png', '', '', '1,2,3', '', '', '', '28,0'),
(7, 'Perfumes', 0, 1, 2, 'data/products/prtfumes.png', '', '2', '', '', '', '', '7,2,0'),
(8, 'Cars', 2, 1, 0, 'data/products/cars.png', '11,13,14,15,8,1,12', '', '1', '', '', '', '8,0'),
(3, 'Laptops', 0, 1, 1, 'data/products/laptops.png', '4,2,10,3,6,16,5,7', '', '', 'Laptops', 'Laptops and netbooks', 'Laptops , netbooks , notebooks, computers', '3,1,0'),
(30, 'Movies', 1, 1, 28, 'data/products/movies.png', '20,21,22', '', '', '', '', '', '30,28,0'),
(31, 'Xbox 360', 0, 1, 29, 'data/products/xbox360.png', '', '', '', '', '', '', '31,29,28,0'),
(32, 'Playstation 3', 1, 1, 29, 'data/products/ps3.png', '', '', '', '', '', '', '32,29,28,0');

-- --------------------------------------------------------

--
-- Table structure for table `store_products_data`
--

CREATE TABLE IF NOT EXISTS `store_products_data` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  `details` longtext NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `img` text NOT NULL,
  `thumb` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `price` float NOT NULL default '0',
  `weight` float NOT NULL default '0',
  `can_shipping` int(11) NOT NULL default '0',
  `available` int(11) NOT NULL default '0',
  `page_title` text NOT NULL,
  `page_description` text NOT NULL,
  `page_keywords` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `name` (`name`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_products_photos`
--

CREATE TABLE IF NOT EXISTS `store_products_photos` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `thumb` text NOT NULL,
  `img` text NOT NULL,
  `product_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_settings`
--

CREATE TABLE IF NOT EXISTS `store_settings` (
  `name` text NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_settings`
--

INSERT INTO `store_settings` (`name`, `value`) VALUES
('snd2friend', '1'),
('vote_song', '1'),
('sitename', 'Allomani'),
('section_name', 'E-Store'),
('songs_add_fields', '5'),
('letters_songs', '1'),
('letters_singers', '1'),
('html_dir', 'ltr'),
('header_keywords', 'Allomani , Products , Services , Store'),
('uploader', '1'),
('uploader_path', 'data'),
('uploader_msg', 'Upload files disabled in demo version'),
('uploader_types', 'jpg,gif,png,rm,mp3,zip'),
('songs_add_limit', '10'),
('singers_groups', '1'),
('songs_perpage', '30'),
('img_cells', '3'),
('vote_clip', '1'),
('snd2friend_clip', '1'),
('votes_expire_hours', '24'),
('copyrights_sitename', 'Allomani'),
('search_min_letters', '4'),
('msgs_count_limit', '30'),
('mailing_email', 'mailing@allomani.com'),
('member_download_only', '2'),
('members_register', '0'),
('news_perpage', '10'),
('vote_file_expire_hours', '24'),
('site_pages_lang', 'en-us'),
('site_pages_encoding', 'windows-1252'),
('enable_browsing', '1'),
('disable_browsing_msg', '<center>Sorry , Website Closed Now.</center>'),
('register_sec_code', '1'),
('auto_email_activate', '0'),
('register_username_exclude_list', 'admin,mod,webmaster'),
('register_username_min_letters', '4'),
('mailing_default_use_html', '1'),
('mailing_default_encoding', ''),
('count_visitors_info', '1'),
('count_visitors_hits', '1'),
('count_online_visitors', '1'),
('enable_search', '1'),
('default_styleid', '1'),
('uploader_thumb_width', '100'),
('uploader_thumb_hieght', '100'),
('ramadv_width', '600'),
('ramadv_height', '200'),
('sitename_in_subpages', '1'),
('section_name_in_subpages', '1'),
('products_perpage', '15'),
('visitors_can_sort_products', '1'),
('products_default_orderby', 'id'),
('products_default_sort', 'desc'),
('videos_member_download_only', '2'),
('songs_multi_select', '1'),
('currency', '$'),
('products_thumb_width', '100'),
('products_thumb_hieght', '100'),
('products_thumb_fixed', '0'),
('header_description', 'Allomani E-Store Script'),
('admin_email', 'sales@allomani.com'),
('orders_perpage', '30'),
('show_paid_option', '1'),
('default_status_change_notify', '1'),
('other_votes_show', '1'),
('other_votes_limit', '10'),
('other_votes_orderby', 'rand()');

-- --------------------------------------------------------

--
-- Table structure for table `store_shipping_methods`
--

CREATE TABLE IF NOT EXISTS `store_shipping_methods` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `min_weight` float NOT NULL default '0',
  `max_weight` float NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `rates_script` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `store_shipping_methods`
--

INSERT INTO `store_shipping_methods` (`id`, `name`, `ord`, `min_weight`, `max_weight`, `active`, `rates_script`) VALUES
(1, 'Ground', 0, 0, 0, 1, ''),
(2, 'FedEx', 1, 0, 0, 1, ''),
(3, 'Aramex', 2, 0, 0, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `store_templates`
--

CREATE TABLE IF NOT EXISTS `store_templates` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `name` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  `protected` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=198 ;

--
-- Dumping data for table `store_templates`
--

INSERT INTO `store_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES
(1, 'Header', 'header', '<BODY onunload="pop_close()" leftMargin=0 topMargin=0>\r\n\r\n\r\n\r\n\r\n<table  width="100%"  border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n	<tr>\r\n		<td>\r\n			<img src="images/store_01.jpg" width="376" height="186" alt=""></td>\r\n		<td background="images/store_02.jpg" width="100%">\r\n			</td>\r\n		<td>\r\n			<img src="images/store_03.jpg" width="219" height="186" alt=""></td>\r\n	</tr>\r\n	</table>\r\n	<table  width="100%"  border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n\r\n	<tr>\r\n		<td background="images/store_04.jpg" width="21">\r\n			<img src="images/store_04.jpg" width="21" height="10" alt=""></td>\r\n		<td width="100%" dir="ltr">\r\n\r\n<br>\r\n<br>', 1, 1),
(2, 'Footer', 'footer', ' <br>\r\n<div align=right>&nbsp;&nbsp;&nbsp;\r\n<?global $styleid;print_style_selection();?>\r\n</div><br>\r\n\r\n</td>\r\n		<td background="images/store_06.jpg" width="25">\r\n			<img src="images/store_06.jpg" width="25" height="10" alt=""></td>\r\n	</tr>\r\n	</table>\r\n	<table  width="100%"  border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n\r\n	<tr>\r\n		<td>\r\n			<img src="images/store_07.jpg" width="198" height="87" alt=""></td>\r\n		<td>\r\n			<img src="images/store_08.jpg" width="1" height="87" alt=""></td>\r\n		<td width="100%" background="images/store_09.jpg">\r\n		</td>\r\n		<td>\r\n			<img src="images/store_10.jpg" width="85" height="87" alt=""></td>\r\n	</tr>\r\n	</table>\r\n</body></html>        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 1),
(3, 'The Blocks', 'block', '<table width="100%" border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n	<tr>\r\n		<td>\r\n			<img src="images/block_01.jpg" width="121" height="51" alt=""></td>\r\n		<td background="images/block_02.jpg" width="100%" height="51">\r\n			</td>\r\n		<td>\r\n			<img src="images/block_03.jpg" width="30" height="51" alt=""></td>\r\n	</tr>\r\n	</table>\r\n	<table width="100%" border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n	<tr>\r\n		<td background="images/block_04.jpg" width="14">\r\n			<img src="images/block_04.jpg" width="14" height="10" alt=""></td>\r\n		<td background="images/block_05.jpg" width="100%" dir="ltr">\r\n			{title}{new_line}{content}</td>\r\n		<td background="images/block_06.jpg" width="14">\r\n			<img src="images/block_06.jpg" width="14" height="10" alt=""></td>\r\n	</tr>\r\n	</table>\r\n	<table width="100%" border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n	<tr>\r\n		<td>\r\n			<img src="images/block_07.jpg" width="121" height="32" alt=""></td>\r\n		<td background="images/block_08.jpg" width="100%" height="32">\r\n			</td>\r\n		<td>\r\n			<img src="images/block_09.jpg" width="30" height="32" alt=""></td>\r\n	</tr>\r\n	</table>\r\n', 1, 1),
(4, 'Tables', 'table', '<table  width="100%"  border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n	<tr>\r\n		<td colspan="3">\r\n			<img src="images/table_01.jpg" width="150" height="61" alt=""></td>\r\n		<td background="images/table_02.jpg" width="100%">\r\n			&nbsp;</td>\r\n		<td colspan="2">\r\n			<img src="images/table_03.jpg" width="42" height="61" alt=""></td>\r\n	</tr>\r\n	</table>\r\n	<table  width="100%"  border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n\r\n	<tr>\r\n		<td background="images/table_04.jpg" width="14">\r\n			<img src="images/table_04.jpg" width="14" height="10" alt=""></td>\r\n		<td width="100%" dir="ltr">\r\n		{title}{new_line}{content}\r\n			</td>\r\n		<td background="images/table_06.jpg" width="11">\r\n			<img src="images/table_06.jpg" width="11" height="10" alt=""></td>\r\n	</tr>\r\n	</table>\r\n	<table  width="100%"  border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n\r\n	<tr>\r\n		<td>\r\n			<img src="images/table_07.jpg" width="61" height="33" alt=""></td>\r\n		<td background="images/table_08.jpg" width="100%">\r\n			<img src="images/table_08.jpg" width="320" height="33" alt=""></td>\r\n		<td>\r\n			<img src="images/table_09.jpg" width="42" height="33" alt=""></td>\r\n	</tr>\r\n	</table>\r\n', 1, 1),
(5, 'Contact us Page', 'contactus', '<center>you can change this text from contactus template in control panel</center>\r\n        ', 1, 1),
(47, 'Email Activation Message', 'email_activation_msg', '<html dir=rtl>\r\n<body>\r\n\r\nHello {name}, <br><br>\r\n\r\n\r\nto Activate your email please click on the following url : <br>\r\n\r\n{url} \r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>\r\n', 1, 1),
(8, 'Javascript Functions', 'js_functions', '<script>\r\n\r\nfunction banner_pop_open(url,name){\r\nmsgwindow=window.open(url,name,"toolbar=yes,scrollbars=yes,resizable=yes,width=650,height=300,top=200,left=200");\r\n}\r\n\r\nfunction banner_pop_close(url,name){\r\nmsgwindow=window.open(url,name,"toolbar=yes,scrollbars=yes,resizable=yes,width=650,height=300,top=200,left=200");\r\n}\r\n\r\n\r\nfunction snd(id)\r\n{\r\nmsgwindow=window.open("send2friend.php?id="+id,"displaywindow","toolbar=no,scrollbars=no,width=400,height=320,top=200,left=200")\r\n}\r\n\r\n\r\n\r\nfunction add2fav(id)\r\n{\r\nmsgwindow=window.open("add2fav.php?id="+id,"displaywindow","toolbar=no,scrollbars=no,width=350,height=150,top=200,left=200")\r\n}\r\n\r\n\r\nfunction CheckAll(form_id)\r\n{\r\n\r\ncount = document.getElementById(form_id).elements.length;\r\n    for (i=0; i < count; i++) \r\n	{\r\n    if((document.getElementById(form_id).elements[i].checked == 1) ||(document.getElementById(form_id).elements[i].checked == 0))\r\n    	{document.getElementById(form_id).elements[i].checked = 1; }\r\n  \r\n	}\r\n}\r\nfunction UncheckAll(form_id){\r\ncount = document.getElementById(form_id).elements.length;\r\n    for (i=0; i < count; i++) \r\n	{\r\n    if((document.getElementById(form_id).elements[i].checked == 1) || (document.getElementById(form_id).elements[i].checked == 0))\r\n    	{document.getElementById(form_id).elements[i].checked = 0; }\r\n\r\n	}\r\n}\r\n\r\nfunction enlarge_pic(sPicURL,title) { \r\nmsgwindow=window.open("enlarge_pic.php?url="+sPicURL+"&title="+title, "","resizable=1,scrollbars=1,HEIGHT=10,WIDTH=10"); \r\n} \r\n\r\nfunction product_photos(pid,id) { \r\nmsgwindow=window.open("product_photos.php?pid="+pid+"&id="+id, "product_photos","resizable=1,scrollbars=1,HEIGHT=10,WIDTH=10"); \r\n}\r\n</script>', 1, 1),
(197, 'Product Photos', 'product_details_photos', '<?\r\nglobal $datap,$phrases,$id;\r\n\r\nprint "<td align=center>\r\n     <a href=''javascript:;'' onclick=\\"product_photos($id,$datap[id]);\\" >\r\n     <img src=\\"$datap[thumb]\\" border=0 alt=\\"".iif($datap[''name''],"$datap[name]\\n")."$phrases[enlarge_pic]\\"></a><br>$datap[name]</td>";\r\n?>', 1, 1),
(22, 'Browse News - Outside', 'browse_news', '<?\r\nglobal $phrases,$data,$links;\r\n$news_date = date("d-m-Y",strtotime($data[''date'']));\r\nprint "<table width=100%><tr><td width=20%><img src=''".get_image($data[''img''])."''></td>\r\n<td><center><font color=''#808080'' class=''title''>$data[title]</font></center><br>\r\n<font color=''#808080''>$news_date : </font> $data[content] ... <a href=''".str_replace(''{id}'',$data[''id''],$links[''links_browse_news''])."''>Read More </a>\r\n<br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font></td></tr></table>";\r\n?>', 1, 1),
(42, 'CSS', 'CSS', '/*------------ BODY ---------------*/\r\n\r\n\r\n\r\nFONT {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n	}\r\nTD {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\nBODY {\r\nFONT-SIZE: 8pt; COLOR: #1266a5 ; FONT-FAMILY: Tahoma; \r\nSCROLLBAR-FACE-COLOR: #ffffff; SCROLLBAR-SHADOW-COLOR: #277eb3; \r\nSCROLLBAR-3DLIGHT-COLOR: #ffffff; SCROLLBAR-ARROW-COLOR: #277eb3; \r\nSCROLLBAR-TRACK-COLOR: #ffffff; SCROLLBAR-DARKSHADOW-COLOR: #ffffff; \r\nBACKGROUND-COLOR: #ffffff; \r\naSCROLLBAR-HIGHLIGHT-COLOR: #ffffff\r\n\r\n	}\r\nP {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n	}\r\nDIV {\r\nFONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n/*---------- TITLES FONT --------------*/\r\n.title {\r\n	FONT-SIZE: 10pt; BACKGROUND: ; COLOR: #458A00; FONT-FAMILY: Tahoma; TEXT-DECORATION: none; font-weight:bold\r\n}\r\n\r\n/*---------- Price and Weight FONT --------------*/\r\n.price {\r\n	FONT-SIZE: 10pt; BACKGROUND: ; COLOR: #8bc41d; FONT-FAMILY: Tahoma; TEXT-DECORATION: none; }\r\n.price_small {\r\n	COLOR: #8bc41d; FONT-FAMILY: Tahoma; TEXT-DECORATION: none; }\r\n\r\n.weight {\r\n	FONT-SIZE: 9pt; BACKGROUND: ; COLOR: #a95f26; FONT-FAMILY: Tahoma; TEXT-DECORATION: none; }\r\n\r\n.weight_small {\r\n	 COLOR: #a95f26; FONT-FAMILY: Tahoma; TEXT-DECORATION: none; }\r\n\r\n\r\n/*------------- LINKS ---------------*/\r\nA:link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n\r\nA:active {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n\r\n}\r\nA:visited {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:hover {\r\n	FONT-SIZE: 8pt; COLOR: #007CF9; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n/*---------- LETTERS LINKS -----------*/\r\nA:link.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n\r\nA:active.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n\r\n}\r\nA:visited.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:hover.big {\r\n	FONT-SIZE: 10pt; COLOR: #007CF9; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n/*----------- PATH BAR LINKS ------------*/\r\nA:link.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:active.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n\r\n}\r\nA:visited.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:hover.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #007CF9; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n\r\n/*---------- Colored Rows COLORS ---------*/\r\n.row_1{\r\nbackground-color: #f7f7f7\r\n}\r\n.row_2{\r\nbackground-color: #FCFCFC \r\n}\r\n\r\n/*--------- MEMBERS MESSAGES FONT--------*/\r\n.messages {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n/*------------ SPARATE LINKE -----------------*/\r\n.separate_line{\r\nBORDER-TOP-WIDTH: 1px; BORDER-LEFT-WIDTH: 1px; BORDER-BOTTOM-WIDTH: 1px; COLOR: #d7ddfd; BORDER-RIGHT-WIDTH: 1px;size:1;\r\n}\r\n/*------------ Search Replace-----------------*/\r\n.search_replace{\r\ncolor: #FF0000;\r\n}\r\n\r\n\r\n/* ---------- Tabs ------------ */\r\n.tabs {\r\nwidth: 100%;\r\n\r\n		margin: 0px;\r\n}\r\n\r\n.tab_active {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-width: 1px;\r\n	border-style: solid;\r\n	background-color: #fff;\r\n	color: #000;\r\n	float: right;\r\n	width: 150px;\r\n	cursor: default;\r\n	font-weight: bold;\r\n	padding: 2px;\r\n	font-size: 10pt;\r\n	text-align: center;\r\n	background-image:url(''images/tabs_shade.gif'')\r\n}\r\n\r\n.tab_inactive {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 1px;\r\n	background-color: #ddd;\r\n	color: #777;\r\n	float: right;\r\n	width: 150px;\r\n        cursor:pointer;\r\n	cursor: hand;\r\n	padding: 2px;\r\n	font-size: 10pt;\r\n	text-align: center;\r\n}\r\n\r\n.tab_content {\r\n	-moz-border-radius: 0px 10px 10px 10px;\r\n	width: 99%;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 0px;\r\n	color: #000;\r\n	float: right;\r\n	text-align: right;\r\n	padding: 10px;\r\n}\r\n\r\n.tab_container {\r\nwidth: 100%;\r\nalign: center;\r\ntext-align: center;\r\n}\r\n\r\n\r\n/* --------- Slider ---------------*/\r\n\r\n.slider_active {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-width: 1px;\r\n	border-style: solid;\r\n	background-color: #fff;\r\n	color: #000;\r\n	float: right;\r\n	\r\n	cursor: default;\r\n	font-weight: bold;\r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n	background-image:url(''images/tabs_shade.gif'')\r\n}\r\n\r\n.slider_inactive {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 1px;\r\n	background-color: #ddd;\r\n	color: #777;\r\n	float: right;\r\n        cursor:pointer;\r\n	cursor: hand;\r\n       \r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n}\r\n\r\n\r\n\r\n\r\n.slider_btnz{\r\ncursor: hand;\r\nwidth:25;\r\n}\r\n\r\n/* ------ Status Bar ------ */\r\n.status_bar {display:none;position:absolute; left:0; top:0; width:100%; border-bottom:solid 1px #aaa; z-index:100; background-image:url(''images/status_shade.gif''); opacity:.85;height:15;text-valign:center;font-size: 10pt; }\r\n\r\n.stauts_bar_loading_img_div {\r\nalign:left;position:absolute;\r\n}', 1, 1),
(23, 'Page head', 'page_head', '<?global $settings;\r\nglobal $section_name,$title_sub,$sitename,$meta_keywords,$meta_description,$settings,$action;\r\n\r\nif(($section_name && $settings[''section_name_in_subpages'']) || $title_sub){\r\n$full_title = iif($sitename && ($settings[''sitename_in_subpages''] || !$action),$sitename,'''');\r\n}else{\r\n$full_title = $sitename;\r\n}\r\nif($section_name && ($settings[''section_name_in_subpages''] || !$action)){\r\n$full_title .= iif($full_title," - $section_name",$section_name);\r\n}\r\n\r\nif($title_sub){\r\n$full_title .= iif($full_title," - $title_sub",$title_sub);\r\n}\r\n\r\n\r\nprint "<html dir=\\"$settings[html_dir]\\">\r\n<head>\r\n";\r\nprint "<!-- no cache headers -->\r\n	<meta http-equiv=\\"Pragma\\" content=\\"no-cache\\" />\r\n	<meta http-equiv=\\"Expires\\" content=\\"-1\\" />\r\n	<meta http-equiv=\\"Cache-Control\\" content=\\"no-cache\\" />\r\n<!-- end no cache headers -->\r\n<meta http-equiv=\\"Content-Type\\" content=\\"text/html; charset=$settings[site_pages_encoding]\\" \r\n\r\n/>\r\n <meta name=\\"generator\\" content=\\"Allomani Store v1.0\\" />\r\n<meta name=\\"keywords\\" content=\\"allomani,allomani.biz,��������,".iif($settings[header_keywords],$settings[header_keywords].",","").$meta_keywords."\\" />\r\n \r\n<meta name=\\"description\\" content=\\"$meta_description\\" />\r\n\r\n<meta name=\\"abstract\\" content=\\"$meta_description\\" />\r\n\r\n<meta name=\\"robots\\" content=\\"index, follow\\" />\r\n<meta name=\\"rating\\" content=\\"General\\" /> \r\n<meta name=\\"distribution\\" content=\\"Global\\" />\r\n\r\n<meta http-equiv=\\"Content-Language\\" content=\\"$settings[site_pages_lang]\\" />\r\n\r\n\r\n\r\n\r\n<LINK href=\\"css.php\\" type=text/css rel=StyleSheet>";\r\n\r\nprint "<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS\\" href=\\"rss.php\\">\r\n\r\n<title>$full_title</title>";\r\n\r\n?>\r\n<script type="text/javascript" src="js/prototype.js"></script>\r\n<script type="text/javascript" src="js/ajax.js"></script>\r\n<script type="text/javascript" src="js/scriptaculous/scriptaculous.js"></script>\r\n<script type="text/javascript" src="js/status_bar.js"></script>', 1, 1),
(43, 'Browse News - Inside', 'browse_news_inside', '<?\r\nglobal $data,$phrases;\r\n\r\n$news_date = date("d-m-Y",strtotime($data[''date'']));\r\n\r\nprint "<table width=100%><tr><td>\r\n\r\n<DIV style=\\"FLOAT: right\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=''".get_image($data[''img''])."''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>$news_date</font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir=\\"ltr\\" align=\\"left\\">\r\n$data[details] <br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font>\r\n\r\n</td></tr>\r\n<tr><td colspan=2 align=left><a href=''news_print.php?id=$data[id]''><img src=''images/print.gif'' alt=''$phrases[printable_copy]'' border=0></a>\r\n\r\n</div>\r\n\r\n</td></tr></table>";\r\n?>\r\n        \r\n        ', 1, 1),
(44, 'Browse News - Print', 'browse_news_print', '<html dir=rtl>\r\n<title>{title}</title>\r\n\r\n<table width=100%>\r\n<tr>\r\n<td>\r\n<p align=center><font size=5><b>{title}</b></font></p>\r\n</td></tr>\r\n\r\n<tr><td>\r\n\r\n<DIV style="FLOAT: right"><TABLE border="0"><TBODY><TR><TD><TABLE border="0"><TBODY><TR><TD align="center">\r\n<img src=''{img}''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>{date} </font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir="ltr" align="left">\r\n{details} <br><br> Writer : <font color=''#808080''>{writer}</font>\r\n</div>\r\n</td></tr>\r\n\r\n</table>   ', 1, 1),
(45, '', 'links_browse_news', 'news_{id}.html', 1, 1),
(46, '', 'links_browse_news_w_pages', 'news_{date}_{start}.html', 1, 1),
(48, 'Email Change Confirmation Messag', 'email_change_confirmation_msg', '<html dir=rtl>\r\n<body>\r\n\r\nHello {username} <br><br>\r\n\r\nthis message to confirm your new email <br><br>\r\n\r\nto confirm email change please open the following url : <br>\r\n\r\n{active_link}\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1),
(49, 'Password rest request message', 'pwd_rest_request_msg', '<html dir=rtl>\r\n<body>\r\n\r\n{name},<br><br>\r\n\r\nYou requested to change your password , to confirm this request please open the following url : \r\n<br>\r\n{url}\r\n<br><br>\r\n\r\nif you didn''t do that please just ignore this message\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}', 1, 1),
(50, 'New Password Message', 'pwd_rest_done_msg', '<html dir=rtl>\r\n<body>\r\n\r\n{name},<br>\r\nYour Password Changed Successfully,\r\n<br><br>\r\n\r\nNew Password : {password}\r\n\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1),
(111, 'Browse Products - Orderby', 'browse_products_orderby', '<?\r\nglobal $phrases,$id,$start,$orderby,$sort,$cat,$field_option,$price_from,$price_to,$orderby_checks,$hide_subcats,$include_subcats,$style;\r\n\r\n\r\nprint "\r\n<form action=index.php method=get>\r\n<input type=hidden name=''action'' value=''browse''>\r\n<input type=hidden name=''cat'' value=''$cat''>\r\n\r\n<img src=''$style[images]/sort.gif''>&nbsp;<b>$phrases[orderby] :</b> &nbsp;";\r\n\r\nif(is_array($field_option)){  \r\nforeach($field_option as $key => $value) { \r\nprint "<input type=hidden name=\\"field_option[$key]\\" value=\\"$value\\">";\r\n}\r\n}\r\n\r\nif($price_from){\r\nprint "<input type=hidden name=\\"price_from\\" value=\\"$price_from\\">";}\r\n\r\nif($price_to){\r\nprint "<input type=hidden name=\\"price_to\\" value=\\"$price_to\\">";}\r\n\r\nif($hide_subcats){\r\nprint "<input type=hidden name=\\"hide_subcats\\" value=\\"1\\">";}\r\n\r\nif($include_subcats){\r\nprint "<input type=hidden name=\\"include_subcats\\" value=\\"1\\">";}\r\n\r\n\r\n\r\nprint "<select name=orderby>";\r\nforeach($orderby_checks as $key=>$value){\r\nprint "<option value=''$value''".iif($orderby==$value," selected").">$key</option>";\r\n}\r\nprint "</select>\r\n\r\n<select name=sort>\r\n<option value=''asc''".iif($sort=="asc"," selected").">$phrases[asc]</option>\r\n<option value=''desc''".iif($sort=="desc"," selected").">$phrases[desc]</option>\r\n</select>\r\n&nbsp;\r\n<input type=submit value='' Process ''>\r\n\r\n</form>";\r\n\r\n?>', 1, 1),
(112, '', 'links_pages', 'page_{id}.html', 1, 1),
(104, '', 'links_browse_products', 'browse_{id}.html', 1, 1),
(103, '', 'links_browse_products_w_pages', 'browse_{id}_{start}.html', 1, 1),
(113, 'New Order Message - Admin', 'msg_new_order_admin', '<html dir=rtl>\r\n<body>\r\n\r\nNew Order From : <br><br>\r\n\r\nOrder # : {order_number} <br>\r\nName : {billing_name} <br>\r\nCountry : {billing_country} <br>\r\nTotal Price : {total_price} <br>\r\nPayment Method : {payment_method_name} <br><br>\r\n\r\n\r\nto review order  : \r\n<br>\r\n{admin_invoice_url} \r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1),
(114, 'New Order Message - Client', 'msg_new_order_client', '<html dir=rtl>\r\n<body>\r\n\r\nHello {billing_name}, <br><br>\r\n\r\n\r\nYour Order Sent Successfully , Your can review your order status by visiting the following url : <br>\r\n\r\n{invoice_url} \r\n\r\n<br><br>\r\n\r\nOrder # : {order_number}\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1),
(115, 'New Order Message Subject - Client', 'msg_new_order_client_subject', 'Order # {order_number}', 1, 1),
(116, 'New Order Message Subject - Admin', 'msg_new_order_admin_subject', 'New Order : # {order_number}', 1, 1),
(196, 'Redirection Page', 'redirection_page', '<?\r\nglobal $style,$re_link,$phrases;\r\n\r\nprint "<center><table width=60% style=\\"border: 1px solid #ccc;color: #333;\\">\r\n<tr><td width=40 align=center><img src=''$style[images]/redirection_icon.gif''></td><td><br>\r\n<center>$phrases[redirection_msg] <a href=\\"$re_link\\">$phrases[click_here]</a></center>\r\n<br>\r\n</td></tr></table></center>";\r\n\r\n?>', 1, 1),
(118, 'Order status change Notification Message Subject', 'msg_order_status_changed_subject', 'Order # {order_number} , Status changed', 1, 1),
(191, '', 'status_bar', '<?\r\nglobal $style;\r\n\r\nprint "<table width=100% style=\\"margin-left:0;margin-right:0;margin-top:0;margin-bottom:0\\" cellpadding=\\"0\\" cellspacing=\\"0\\"><tr><td width=25>\r\n<img src=''$style[images]/ajax_loading.gif'' id=''status_bar_loading_img''>\r\n</td><td>\r\n<div id=''stauts_bar_text''>\r\nLoading ...\r\n</div>\r\n</td></table>";\r\n?>', 1, 1),
(192, '', 'blocks_banners', '<?\r\nglobal $data;\r\nopen_block();\r\n\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a></center>";\r\n\r\nclose_block();\r\n?>', 1, 1),
(193, '', 'center_banners', '<?\r\nglobal $data;\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a><br></center>";\r\n?>', 1, 1),
(194, '', 'browse_products_cats', '<?\r\nglobal $data,$style,$links;\r\n\r\nprint"<center><a href=''".str_replace(''{id}'',$data[''id''],$links[''links_browse_products''])."''>\r\n            <img border=0 src=''".get_image($data[''img''],"$style[images]/folder.gif")."'' title=\\"$data[name]\\">\r\n<br>$data[name] </a>\r\n\r\n\r\n </center>";\r\n?>', 1, 1),
(195, '', 'checkout_done', '<?\r\nglobal $order_id,$total_price,$settings;\r\n \r\nopen_table("Your Order Sent Successfully");\r\n print "<b> Order #: </b> $order_id <br>\r\n <b>Total Price: </b> $total_price $settings[currency]\r\n <br><br>\r\n <center><form action=index.php method=get>\r\n <input type=hidden name=action value=''invoice''>\r\n <input type=hidden name=id value=''$order_id''>\r\n <input type=submit value='' View / Pay Invoice''>\r\n </form>";\r\n close_table();\r\n\r\n print "<script>cart_clear();</script>";   \r\n\r\n?>', 1, 1),
(108, 'Browse Products - Header', 'browse_products_header', '<?\r\nglobal $data_cat,$phrases,$action,$field_option,$cat,$style;\r\n\r\nif($action=="browse"){\r\ncompile_template(get_template(''browse_products_orderby'')); \r\n}\r\n\r\n\r\nif($action){\r\nopen_table(iif($action=="search",$phrases[''search_results''],$data_cat[''name'']));\r\n}\r\n?>\r\n<hr class=separate_line size=1>', 1, 1),
(109, 'Browse Products - Footer', 'browse_products_footer', '<?\r\nglobal $action;\r\nif($action){\r\nclose_table();\r\n}\r\n?>', 1, 1),
(110, 'Browse Products - Seperator', 'browse_products_spect', '', 1, 1),
(106, '', 'links_product_details', 'details_{id}.html', 1, 1),
(107, '', 'no_title_no_border', '{content}', 0, 1),
(105, 'Browse Products', 'browse_products', '<?\r\nglobal $data,$data_cat,$settings,$phrases,$action,$is_user_cp,$global_align_x,$start,$links,$style,$include_subcats;\r\n\r\n$start=intval($start);\r\n\r\n$details_link = str_replace(''{id}'',$data[''id''],$links[''links_product_details'']);\r\n\r\nprint "<table width=100%><tr>\r\n<td align=center width=120>\r\n<a href=''$details_link''><img border=0 title=''$phrases[the_name] : $data[name] \\n$phrases[add_date] : ".substr($data[''date''],0,10)."'' src=''".get_image($data[''thumb''])."''></a>\r\n</td><td>";\r\n\r\nif($action=="favorites" || $action=="favorites_del"){\r\nprint "<div align=$global_align_x><a href=''index.php?action=favorites_del&id=$data[fav_id]&start=$start'' onClick=\\"return confirm(''".$phrases[''are_you_sure'']."'');\\"><img src=''$style[images]/del_small.gif'' border=0>&nbsp; $phrases[remove_from_fav]</a></div>";\r\n}\r\n\r\nprint "<a href=''$details_link''><font size=2><b>$data[name]</b></font> </a>\r\n<br>\r\n<br>";\r\nif($data[''content'']){\r\nprint "$data[content]\r\n<br><br>";\r\n}\r\n\r\nget_short_details_fields_data($data[''id''],$data[''cat'']);\r\n\r\nif($data[''weight'']){\r\nprint "<img src=''$style[images]/weight.gif''><span class=weight_small><b> $phrases[the_weight] : </b> ".iif(strchr($data[''weight''],"."),$data[''weight''],number_format($data[''weight''],2,".",","))." $phrases[kg] <br>";\r\n}\r\n\r\nprint "\r\n<img src=''$style[images]/price.gif''>&nbsp; <span class=price_small><b>$phrases[the_price] :</b> $data[price] $settings[currency]</span>\r\n<br>\r\n<a href=''$details_link''><img src=''$style[images]/info.gif'' border=0>&nbsp;$phrases[product_details]</a>\r\n\r\n";\r\n\r\nif(($action==''search'' || !$action || $include_subcats) && $data_cat[''id'']){\r\nprint "<br><br><a href=''".str_replace(''{id}'',$data_cat[''id''],$links[''links_browse_products''])\r\n."''><img src=''$style[images]/cat.gif'' border=0>&nbsp;$data_cat[name]</a>";\r\n}\r\n\r\n print " <br>\r\n<div align=$global_align_x>";\r\nif($data[''available'']){\r\nprint "<img src=''$style[images]/cart_icon.gif''> <a href=''javascript:;'' onClick=\\"cart_add_item($data[id]);\\">$phrases[add_to_cart]</a>";\r\n}else{\r\nprint "$phrases[not_available_now]";\r\n}\r\nprint "</div>\r\n\r\n</td>\r\n\r\n</tr></table><hr class=separate_line size=1>";\r\n\r\n?> ', 1, 1),
(189, 'Product Details Page', 'product_details', '<?\r\nglobal $data,$fields_content,$style,$global_align,$global_align_x,$scripturl,$phrases,$settings;\r\n\r\nif($data[''thumb'']){\r\n     print "<a href=''javascript:;'' onclick=\\"enlarge_pic(''$data[img]'',''".htmlspecialchars(str_replace(array("?","''"),"",$data[''name'']))."'');\\" >\r\n     <img src=\\"$data[thumb]\\" border=0 alt=\\"$data[name]\\n $phrases[enlarge_pic]\\"></a><br><br>";\r\n }\r\n\r\n\r\nprint $fields_content ;\r\n\r\nprint "\r\n $data[details] \r\n <br><br>";\r\n \r\n if($data[''weight'']){\r\n print "<hr class=''separate_line'' size=1 width=50% align=$global_align>\r\n <img src=''$style[images]/weight_details.gif''><span class=weight><b> $phrases[the_weight] : </b> ".iif(strchr($data[''weight''],"."),$data[''weight''],number_format($data[''weight''],2,".",","))." $phrases[kg]   </span>";\r\n }\r\n \r\n print "<hr class=''separate_line'' size=1>\r\n <table width=100%><tr><td align=$global_align>\r\n <img src=''$style[images]/price_details.gif''><span class=price>&nbsp;<b>$phrases[the_price] : </b> $data[price] $settings[currency] </span>\r\n </td>\r\n <td align=$global_align_x>";\r\n \r\n if($data[''available'']){ \r\n print "<img src=''$style[images]/cart_icon.gif''> <a href=''javascript:;'' onClick=\\"cart_add_item($data[id]);\\">$phrases[add_to_cart]</a>";\r\n }else{\r\n     print "$phrases[not_available_now]";\r\n }\r\n print "</td></table>\r\n \r\n <hr class=''separate_line'' size=1>\r\n <br>\r\n \r\n \r\n \r\n <div align=''$global_align_x''>\r\n <a href=\\"javascript:add2fav($data[id]);\\"><img src=\\"$style[images]/favorite.gif\\" border=0 alt=\\"$phrases[add2favorite]\\"></a>\r\n &nbsp;\r\n <a href=''http://www.facebook.com/sharer.php?u=".urlencode($scripturl."/".get_template(''links_product_details'',''{id}'',$data[''id'']))."'' target=_blank><img src=''$style[images]/facebook.gif'' alt=''Share with Facebook'' border=0></a>\r\n </div>";\r\n\r\n?>', 1, 1),
(117, 'Order status change Notification Message', 'msg_order_status_changed', '<html dir=rtl>\r\n<body>\r\n\r\nHello {billing_name}, <br><br>\r\n\r\n\r\nWe want to inform you the you order # {order_number} Status has been changed from {old_status} to {new_status}\r\n\r\n<br><br>\r\n\r\nyou can review your order by visiting the following url  : <br>\r\n\r\n{invoice_url} \r\n\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `store_templates_cats`
--

CREATE TABLE IF NOT EXISTS `store_templates_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `selectable` int(11) NOT NULL default '0',
  `images` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `store_templates_cats`
--

INSERT INTO `store_templates_cats` (`id`, `name`, `selectable`, `images`) VALUES
(1, 'Default Style', 1, 'images');

-- --------------------------------------------------------

--
-- Table structure for table `store_user`
--

CREATE TABLE IF NOT EXISTS `store_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `group_id` int(11) NOT NULL default '0',
  `permisions` text NOT NULL,
  `permisions_videos` text NOT NULL,
  `cp_permisions` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `store_votes`
--

CREATE TABLE IF NOT EXISTS `store_votes` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `cnt` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `store_votes`
--

INSERT INTO `store_votes` (`id`, `title`, `cnt`, `cat`) VALUES
(1, 'Excellent', 27, 1),
(2, 'Good', 2, 1),
(3, 'Bad', 1, 1),
(4, '1', 0, 2),
(5, '2', 0, 2),
(6, '1', 0, 3),
(8, '2', 0, 3),
(9, '3', 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `store_votes_cats`
--

CREATE TABLE IF NOT EXISTS `store_votes_cats` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `store_votes_cats`
--

INSERT INTO `store_votes_cats` (`id`, `title`, `active`) VALUES
(1, 'Site Rate', 1),
(2, 'Test Vote', 0),
(3, 'Test vote 2', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
